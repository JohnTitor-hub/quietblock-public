import { test, expect } from "./fixtures.mjs";

test("trusted downloads and page caches cannot invent repairs, while packaged repairs and exceptions remain active", async ({
  extension,
  laboratory,
}) => {
  const control = await extension.context.newPage();
  await control.goto(`chrome-extension://${extension.id}/test-control.html`);
  const command = (command, extra = {}) =>
    control.evaluate(
      (message) =>
        chrome.runtime.sendMessage({ channel: "quietblock", ...message }),
      { command, ...extra },
    );
  const original = (await command("status")).value.settings;
  const page = await extension.context.newPage();
  await page.goto(laboratory.url);
  const detector = () =>
    page
      .evaluate(() => window.adBlocked)
      .catch((error) => {
        if (error.message.includes("Execution context was destroyed"))
          return undefined;
        throw error;
      });
  await expect.poll(detector).toBe(false);
  const storage = await extension.context.newCDPSession(page);
  const storageId = {
    securityOrigin: new URL(laboratory.url).origin,
    isLocalStorage: false,
  };
  const { entries } = await storage.send("DOMStorage.getDOMStorageItems", {
    storageId,
  });
  const cached = JSON.parse(new Map(entries).get("qb-filters-config"));
  expect(cached.catalog).toBeTruthy();
  expect(cached.repairs.length).toBeGreaterThan(0);
  cached.filters = ["override-property-read injectedMarker true"];
  cached.repairs.push([999999, [0]]);
  await storage.send("DOMStorage.setDOMStorageItem", {
    storageId,
    key: "qb-filters-config",
    value: JSON.stringify(cached),
  });
  await storage.detach();
  await page.reload();
  await expect.poll(detector).toBe(false);
  expect(await page.evaluate(() => window.injectedMarker)).toBeUndefined();
  await extension.context.route(
    "https://filters.quietblock.test/laboratory-diff.json*",
    (route) =>
      route.fulfill({
        contentType: "application/json",
        body: JSON.stringify({
          filters: {
            add: [
              "||ads.quietblock.test^*/fresh.js$script",
              "lab.quietblock.test##.fresh-ad",
              "lab.quietblock.test#$#override-property-read downloadedMarker true",
            ],
            remove: [
              "lab.quietblock.test#$#override-property-read adBlocked false",
            ],
          },
        }),
      }),
  );
  await command("update");
  await expect
    .poll(
      async () =>
        (await command("status")).value.lists.find(
          (list) => list.url === original.enabledLists[0],
        ).downloadStatus,
    )
    .toBe("synchronize_ok");
  await expect
    .poll(() =>
      extension.worker.evaluate(async () =>
        (await chrome.declarativeNetRequest.getDynamicRules()).some((rule) =>
          rule.condition.urlFilter?.includes("fresh.js"),
        ),
      ),
    )
    .toBe(true);
  await page.reload();
  await expect.poll(detector).toBe(false);
  expect(await page.evaluate(() => window.downloadedMarker)).toBeUndefined();
  await page.evaluate(() =>
    document.body.insertAdjacentHTML(
      "beforeend",
      '<div class="fresh-ad">Fresh advertisement</div>',
    ),
  );
  await expect(page.locator(".fresh-ad")).toBeHidden();
  const rejected = await command("save", {
    settings: {
      ...original,
      customFilters: [
        "lab.quietblock.test#$#override-property-read userMarker true",
      ],
    },
  });
  expect(rejected.ok).toBe(false);
  expect(rejected.error).toContain("extension update");
  expect((await command("status")).value.settings).toEqual(original);
  expect(
    (
      await command("save", {
        settings: {
          ...original,
          customFilters: [
            "lab.quietblock.test#@$#override-property-read adBlocked false",
          ],
        },
      })
    ).ok,
  ).toBe(true);
  await page.reload();
  await expect.poll(detector).toBe(true);
  expect(extension.errors).toEqual([]);
});

test("untrusted subscriptions update without privileged snippets and retain rules on failed downloads", async ({
  extension,
  laboratory,
}) => {
  const control = await extension.context.newPage();
  await control.goto(`chrome-extension://${extension.id}/test-control.html`);
  const command = (command, extra = {}) =>
    control.evaluate(
      (message) =>
        chrome.runtime.sendMessage({ channel: "quietblock", ...message }),
      { command, ...extra },
    );
  let body =
    "[Adblock Plus 2.0]\n! Title: Local update test\n! Version: 1\n||ads.quietblock.test^*/custom.js$script\nlab.quietblock.test#$#override-property-read untrustedMarker true\n";
  let failed = false;
  const downloads = [];
  await extension.context.route(
    "https://filters.quietblock.test/custom.txt",
    (route) => {
      downloads.push(route.request().url());
      return route.fulfill({
        status: failed ? 503 : 200,
        body,
        contentType: "text/plain",
      });
    },
  );
  const original = (await command("status")).value.settings;
  const url = "https://filters.quietblock.test/custom.txt";
  expect(
    (
      await command("save", {
        settings: {
          ...original,
          customLists: [{ url, title: "Local update test" }],
          enabledLists: [...original.enabledLists, url],
        },
      })
    ).ok,
  ).toBe(true);
  const list = async () =>
    (await command("status")).value.lists.find((item) => item.url === url);
  await expect
    .poll(async () => (await list()).downloadStatus)
    .toBe("synchronize_ok");
  await expect
    .poll(() =>
      extension.worker.evaluate(async () =>
        (await chrome.declarativeNetRequest.getDynamicRules()).some((rule) =>
          rule.condition.urlFilter?.includes("custom.js"),
        ),
      ),
    )
    .toBe(true);
  const page = await extension.context.newPage();
  await page.goto(laboratory.url);
  expect(await page.evaluate(() => window.untrustedMarker)).toBeUndefined();
  failed = true;
  await command("update");
  await expect
    .poll(async () => (await list()).downloadStatus)
    .toBe("synchronize_connection_error");
  expect(
    await extension.worker.evaluate(async () =>
      (await chrome.declarativeNetRequest.getDynamicRules()).some((rule) =>
        rule.condition.urlFilter?.includes("custom.js"),
      ),
    ),
  ).toBe(true);
  expect(downloads.length).toBeGreaterThanOrEqual(2);
  expect(downloads.every((value) => value === url)).toBe(true);
  failed = false;
  body =
    "[Adblock Plus 2.0]\n! Version: 2\n" +
    Array.from(
      { length: 30_001 },
      (_, index) => `||quota${index}.example^`,
    ).join("\n");
  await command("update");
  await expect
    .poll(async () => (await list()).downloadStatus, { timeout: 15_000 })
    .toBe("synchronize_too_many_filters");
  expect(
    await extension.worker.evaluate(async () =>
      (await chrome.declarativeNetRequest.getDynamicRules()).some((rule) =>
        rule.condition.urlFilter?.includes("custom.js"),
      ),
    ),
  ).toBe(true);
  expect((await command("status")).value.settings).toMatchObject({
    customLists: [{ url, title: "Local update test" }],
  });
});
