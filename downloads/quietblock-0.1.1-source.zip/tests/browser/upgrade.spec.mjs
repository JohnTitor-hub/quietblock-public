import { chromium } from "@playwright/test";
import { cp, mkdtemp, mkdir, readFile, rm } from "node:fs/promises";
import path from "node:path";
import { test, expect } from "./fixtures.mjs";

const previous = process.env.QUIETBLOCK_PREVIOUS_EXTENSION;
const privateBackup = process.env.QUIETBLOCK_SETTINGS_BACKUP;
for (const fixture of privateBackup
  ? ["sample", "private backup"]
  : ["sample"]) {
  test(`0.1.0 quota failure upgrades to the current baseline and preserves ${fixture} settings`, async ({
    laboratory,
  }) => {
    test.skip(
      !previous,
      "Provide the previous verified extension for release upgrade verification.",
    );
    test.setTimeout(90_000);
    await mkdir(".cache/profiles", { recursive: true });
    const temporary = await mkdtemp(path.resolve(".cache/profiles/upgrade-"));
    const live = path.join(temporary, "extension");
    const profile = path.join(temporary, "profile");
    const candidate = path.resolve(process.env.QUIETBLOCK_EXTENSION || "dist");
    const quota = JSON.parse(
      await readFile("artifacts/filter-update-quota.json", "utf8"),
    );
    const candidateManifest = JSON.parse(
      await readFile(path.join(candidate, "manifest.json"), "utf8"),
    );
    expect(quota.version).toBe(candidateManifest.version);
    expect(quota.passed).toBe(true);
    const previousMap = JSON.parse(
      await readFile(
        path.join(
          previous,
          "rules/8C13E995-8F06-4927-BEA7-6C845FB7EEBF.json.map",
        ),
        "utf8",
      ),
    );
    const removed = [];
    const disabled = new Set();
    for (const [text, ids] of previousMap) {
      removed.push(text);
      ids.forEach((id) => disabled.add(id));
      if (disabled.size > 5000) break;
    }
    let context;
    let old = true;
    const launch = async () => {
      context = await chromium.launchPersistentContext(profile, {
        channel: "chromium",
        headless: true,
        args: [
          "--enable-unsafe-extension-debugging",
          `--disable-extensions-except=${live}`,
          `--load-extension=${live}`,
          "--host-resolver-rules=MAP *.quietblock.test 127.0.0.1, MAP ad.doubleclick.net 127.0.0.1",
          "--no-proxy-server",
        ],
      });
      await context.route("https://**/*", async (route) => {
        const url = new URL(route.request().url());
        const update = old
          ? {
              filters: {
                add: url.pathname.includes("abp-filters-anti-cv")
                  ? ["||obsolete.quietblock.test^$script"]
                  : [],
                remove: url.pathname.includes("/easylist/") ? removed : [],
              },
            }
          : quota.updates.find(
              (item) => new URL(item.diffUrl).pathname === url.pathname,
            )?.delta;
        if (!update)
          throw new Error("Unexpected filter endpoint during upgrade test");
        await route.fulfill({
          contentType: "application/json",
          headers: { date: new Date().toUTCString() },
          body: JSON.stringify(update),
        });
      });
      return connect();
    };
    const connect = async () => {
      const worker =
        context.serviceWorkers()[0] ||
        (await context.waitForEvent("serviceworker"));
      const id = new URL(worker.url()).host;
      const page = await context.newPage();
      await page.goto(`chrome-extension://${id}/options.html`);
      const command = (command, extra = {}) =>
        page.evaluate(
          (message) =>
            chrome.runtime.sendMessage({ channel: "quietblock", ...message }),
          { command, ...extra },
        );
      await expect.poll(() => command("status")).toMatchObject({ ok: true });
      return { id, page, worker: context.serviceWorkers()[0], command };
    };
    try {
      await cp(path.resolve(previous), live, { recursive: true });
      let extension = await launch();
      expect(
        await extension.worker.evaluate(
          () => chrome.runtime.getManifest().version,
        ),
      ).toBe("0.1.0");
      const originalId = extension.id;
      const defaults = (await extension.command("status")).value.settings;
      const settings =
        fixture === "private backup"
          ? JSON.parse(await readFile(privateBackup, "utf8"))
          : {
              ...defaults,
              enabledLists: defaults.enabledLists.filter(
                (url) => !url.includes("easyprivacy"),
              ),
              pausedHosts: ["paused.example.com", "localhost"],
              customFilters: [
                "@@||api.example.com^",
                "lab.quietblock.test##.upgrade-rule",
              ],
              snippetCacheDisabledHosts: ["cache.example.com"],
            };
      expect((await extension.command("save", { settings })).ok).toBe(true);
      await extension.command("update");
      await expect
        .poll(
          async () =>
            (await extension.command("status")).value.lists.find(
              (list) => list.title === "EasyList",
            ).downloadStatus,
        )
        .toBe("synchronize_diff_too_many_filters");
      await expect
        .poll(() =>
          extension.worker.evaluate(async () =>
            (await chrome.declarativeNetRequest.getDynamicRules()).some(
              (rule) =>
                rule.condition.urlFilter?.includes("obsolete.quietblock.test"),
            ),
          ),
        )
        .toBe(true);
      await extension.page.close();
      old = false;
      await rm(live, { recursive: true });
      await cp(candidate, live, { recursive: true });
      const cdp = await context.browser().newBrowserCDPSession();
      await cdp.send("Extensions.loadUnpacked", { path: live });
      extension = await connect();
      expect(extension.id).toBe(originalId);
      expect(
        await extension.worker.evaluate(
          () => chrome.runtime.getManifest().version,
        ),
      ).toBe(candidateManifest.version);
      expect((await extension.command("status")).value.settings).toEqual(
        settings,
      );
      expect(
        await extension.worker.evaluate(async () =>
          (await chrome.declarativeNetRequest.getDynamicRules()).some((rule) =>
            rule.condition.urlFilter?.includes("obsolete.quietblock.test"),
          ),
        ),
      ).toBe(false);
      await extension.command("update");
      await expect
        .poll(async () =>
          (await extension.command("status")).value.lists
            .filter((list) => list.enabled)
            .every(
              (list) =>
                list.downloadStatus === "synchronize_ok" && !list.downloading,
            ),
        )
        .toBe(true);
      const content = await context.newPage();
      await content.goto(laboratory.url + "/production");
      await expect(content.locator("h1")).toBeVisible();
      await expect(content.locator(".ad-banner-300")).toBeHidden();
      expect(
        laboratory.requests.some(
          (request) => request.path === "/advertisement.js",
        ),
      ).toBe(false);
      if (fixture === "sample") {
        await content.evaluate(() =>
          document.body.insertAdjacentHTML(
            "beforeend",
            '<div class="upgrade-rule">Custom rule probe</div>',
          ),
        );
        await expect(content.locator(".upgrade-rule")).toBeHidden();
      }
      await extension.page.reload();
      expect((await extension.command("status")).value.settings).toEqual(
        settings,
      );
      const enabled = await extension.worker.evaluate(() =>
        chrome.declarativeNetRequest.getEnabledRulesets(),
      );
      const state = (await extension.command("status")).value;
      expect(enabled.sort()).toEqual(
        state.catalog
          .filter((list) => settings.enabledLists.includes(list.url))
          .map((list) => list.id)
          .sort(),
      );
    } finally {
      if (context) await context.close();
      await rm(temporary, { recursive: true, force: true });
    }
  });
}
