import assert from "node:assert/strict";
import test from "node:test";
import { checkDisabledStaticQuota } from "../../tools/check-filter-quota.mjs";

test("the disabled-static quota counts unique rule IDs per enabled ruleset and enforces the shared 5,000-rule limit", () => {
  const first = {
    id: "ads",
    title: "Ads",
    enabled: true,
    sourceMap: [
      ["removed", Array.from({ length: 4999 }, (_, i) => i + 1)],
      ["duplicate", [1]],
    ],
    removed: ["removed", "removed", "duplicate", "cosmetic-only"],
  };
  const second = {
    id: "privacy",
    title: "Privacy",
    enabled: true,
    sourceMap: [["other", [1]]],
    removed: ["other"],
  };
  assert.equal(
    checkDisabledStaticQuota([first, second]).disabledStaticRules,
    5000,
  );
  assert.equal(checkDisabledStaticQuota([first, second]).passed, true);
  second.sourceMap[0][1].push(2);
  assert.equal(checkDisabledStaticQuota([first, second]).passed, false);
  assert.equal(checkDisabledStaticQuota([first, second]).remaining, -1);
  second.enabled = false;
  assert.equal(
    checkDisabledStaticQuota([first, second]).disabledStaticRules,
    4999,
  );
});
