import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

export function checkDisabledStaticQuota(lists) {
  const enabled = lists.filter((list) => list.enabled);
  const counts = enabled.map(({ id, title, sourceMap, removed }) => {
    const mapping = new Map(sourceMap);
    const ids = new Set(removed.flatMap((text) => mapping.get(text) || []));
    return { id, title, disabledStaticRules: ids.size };
  });
  const disabledStaticRules = counts.reduce(
    (total, list) => total + list.disabledStaticRules,
    0,
  );
  return {
    limit: 5000,
    disabledStaticRules,
    remaining: 5000 - disabledStaticRules,
    passed: disabledStaticRules <= 5000,
    lists: counts,
  };
}

export async function checkFilterQuota(extensionRoot = "dist") {
  const root = path.resolve(extensionRoot);
  const provenance = JSON.parse(
    await readFile(path.join(root, "notices/filter-provenance.json"), "utf8"),
  );
  const manifest = JSON.parse(
    await readFile(path.join(root, "manifest.json"), "utf8"),
  );
  const enabled = new Set(
    manifest.declarative_net_request.rule_resources
      .filter((ruleset) => ruleset.enabled)
      .map((ruleset) => ruleset.id),
  );
  const updates = await Promise.all(
    provenance.snapshots
      .filter((list) => enabled.has(list.id))
      .map(async (list) => {
        const url = new URL(list.diff_url);
        url.searchParams.set("lastVersion", String(list.version));
        const response = await fetch(url, {
          signal: AbortSignal.timeout(30_000),
        });
        if (!response.ok)
          throw new Error(`${list.title}: HTTP ${response.status}`);
        const bytes = Buffer.from(await response.arrayBuffer());
        const delta = JSON.parse(bytes);
        if (
          ![delta.filters?.add, delta.filters?.remove].every(
            (values) =>
              Array.isArray(values) &&
              values.every((value) => typeof value === "string"),
          )
        )
          throw new Error(`${list.title}: invalid filter delta`);
        return {
          id: list.id,
          title: list.title,
          enabled: true,
          baselineVersion: list.version,
          diffUrl: url.href,
          sha256: createHash("sha256").update(bytes).digest("hex"),
          sourceMap: JSON.parse(
            await readFile(
              path.join(root, `rules/${list.id}.json.map`),
              "utf8",
            ),
          ),
          removed: delta.filters.remove,
          delta,
        };
      }),
  );
  const quota = checkDisabledStaticQuota(updates);
  const report = {
    version: manifest.version,
    checkedAt: new Date().toISOString(),
    ...quota,
    updates: updates.map(
      ({ sourceMap, removed, enabled, ...update }) => update,
    ),
  };
  await mkdir("artifacts", { recursive: true });
  await writeFile(
    "artifacts/filter-update-quota.json",
    JSON.stringify(report, null, 2) + "\n",
  );
  if (!report.passed)
    throw new Error(
      `Filter delta needs ${report.disabledStaticRules} disabled static rules; Chrome allows ${report.limit}. Refresh bundled snapshots before release.`,
    );
  return report;
}

if (
  process.argv[1] &&
  path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  try {
    const report = await checkFilterQuota(process.argv[2]);
    console.log(
      `Enabled-list deltas need ${report.disabledStaticRules}/${report.limit} disabled static rules (${report.remaining} remaining).`,
    );
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
