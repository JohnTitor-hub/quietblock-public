import { cp, mkdir, readFile, readdir, writeFile } from "node:fs/promises";
export async function copyNotices(outdir, metafile, reference = false) {
  await mkdir(`${outdir}/notices`, { recursive: true });
  await cp(
    "vendor/eyeo-sdk/LICENSE-THIRD-PARTY",
    `${outdir}/notices/eyeo-third-party.txt`,
  );
  await cp(
    "vendor/eyeo-sdk/adblockpluscore/vendor/jsbn/LICENSE",
    `${outdir}/notices/jsbn.txt`,
  );
  await cp("vendor/eyeo-snippets/LICENSE.js", `${outdir}/notices/snippets.txt`);
  const embedded = await readFile(
    "vendor/eyeo-snippets/source/conditional-hiding/hide-if-matches-xpath3-dependency.js",
    "utf8",
  );
  await writeFile(
    `${outdir}/notices/snippets-embedded.txt`,
    embedded
      .split("\n")
      .filter((line) => line.trim().startsWith("//"))
      .map((line) => line.trim().slice(2).trimStart())
      .join("\n"),
  );
  const packages = new Set(
    Object.keys(metafile.inputs)
      .filter((file) => file.startsWith("node_modules/"))
      .map((file) =>
        file
          .split("/")
          .slice(1, file.split("/")[1].startsWith("@") ? 3 : 2)
          .join("/"),
      ),
  );
  const dependencies = [];
  for (const name of packages) {
    const root = `node_modules/${name}`,
      pkg = JSON.parse(await readFile(`${root}/package.json`, "utf8"));
    const license = (await readdir(root)).find((file) =>
      /^licen[sc]e(?:[.-].*)?$/i.test(file),
    );
    if (!license && !reference) throw new Error(`Missing license: ${name}`);
    if (license)
      await cp(
        `${root}/${license}`,
        `${outdir}/notices/${name.replaceAll("/", "-")}.txt`,
      );
    dependencies.push({ name, version: pkg.version, license: pkg.license });
  }
  await writeFile(
    `${outdir}/notices/dependencies.json`,
    JSON.stringify(dependencies, null, 2),
  );
  await cp("filters/lock.json", `${outdir}/notices/filter-provenance.json`);
  if (!reference)
    await cp(
      "dependencies-source.lock.json",
      `${outdir}/notices/dependency-source-provenance.json`,
    );
}
