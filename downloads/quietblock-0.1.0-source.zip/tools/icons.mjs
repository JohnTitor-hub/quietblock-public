import { deflateSync } from "node:zlib";
import { mkdir, writeFile } from "node:fs/promises";
function chunk(type, data) {
  const bytes = Buffer.concat([Buffer.from(type), data]);
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++)
      crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
  }
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length);
  const checksum = Buffer.alloc(4);
  checksum.writeUInt32BE((crc ^ 0xffffffff) >>> 0);
  return Buffer.concat([length, bytes, checksum]);
}
function inside(x, y) {
  return (
    Math.max(Math.abs(x - 16) - 7, 0) ** 2 +
      Math.max(Math.abs(y - 16) - 7, 0) ** 2 <=
    8 ** 2
  );
}
function stroke(x, y, a, b, c, d) {
  const t = Math.max(
    0,
    Math.min(
      1,
      ((x - a) * (c - a) + (y - b) * (d - b)) / ((c - a) ** 2 + (d - b) ** 2),
    ),
  );
  return (x - a - t * (c - a)) ** 2 + (y - b - t * (d - b)) ** 2 < 1.75 ** 2;
}
export async function makeIcons(outdir) {
  await mkdir(`${outdir}/icons`, { recursive: true });
  for (const size of [16, 32, 48, 128]) {
    const pixels = Buffer.alloc(size * (1 + size * 4));
    for (let y = 0; y < size; y++)
      for (let x = 0; x < size; x++) {
        let alpha = 0;
        const rgb = [0, 0, 0];
        for (let v = 0; v < 4; v++)
          for (let u = 0; u < 4; u++) {
            const px = ((x + (u + 0.5) / 4) * 32) / size,
              py = ((y + (v + 0.5) / 4) * 32) / size;
            if (!inside(px, py)) continue;
            alpha++;
            const color = stroke(px, py, 18.5, 18.5, 25.5, 25.5)
              ? [166, 201, 180]
              : Math.abs(Math.hypot(px - 16, py - 16) - 8) < 1.75
                ? [255, 253, 248]
                : [32, 42, 42];
            color.forEach((value, index) => (rgb[index] += value));
          }
        const offset = y * (1 + size * 4) + 1 + x * 4;
        if (alpha) {
          rgb.forEach(
            (value, index) =>
              (pixels[offset + index] = Math.round(value / alpha)),
          );
          pixels[offset + 3] = Math.round((alpha * 255) / 16);
        }
      }
    const header = Buffer.alloc(13);
    header.writeUInt32BE(size, 0);
    header.writeUInt32BE(size, 4);
    header[8] = 8;
    header[9] = 6;
    await writeFile(
      `${outdir}/icons/${size}.png`,
      Buffer.concat([
        Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
        chunk("IHDR", header),
        chunk("IDAT", deflateSync(pixels)),
        chunk("IEND", Buffer.alloc(0)),
      ]),
    );
  }
}
