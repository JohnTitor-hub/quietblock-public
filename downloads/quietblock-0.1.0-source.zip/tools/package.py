"""Create a deterministic Chrome-loadable ZIP; exclude development artifacts."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path("dist")
if not (root / "manifest.json").is_file():
    raise SystemExit("Run npm run build first")
manifest = json.loads((root / "manifest.json").read_text())
target = Path("artifacts") / f"quietblock-{manifest['version']}.zip"
target.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for source in sorted(root.rglob("*")):
        if source.is_file() and "_metadata" not in source.relative_to(root).parts:
            info = zipfile.ZipInfo(source.relative_to(root).as_posix(), (2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, source.read_bytes(), compresslevel=9)
digest = hashlib.sha256(target.read_bytes()).hexdigest()
target.with_suffix(".zip.sha256").write_text(f"{digest}  {target.name}\n")
print(f"{target}: {target.stat().st_size:,} bytes; SHA256 {digest}")
