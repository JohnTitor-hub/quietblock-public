// Chrome exposes extension popups and worker heaps as targets outside Playwright's Page API.
export async function attachTarget(cdp, targetId, onEvent = () => {}) {
  const { sessionId } = await cdp.send("Target.attachToTarget", {
    targetId,
    flatten: false,
  });
  let sequence = 0;
  const pending = new Map();
  const listener = (event) => {
    if (event.sessionId !== sessionId) return;
    const response = JSON.parse(event.message),
      callback = pending.get(response.id);
    if (response.method) onEvent(response);
    if (callback) {
      pending.delete(response.id);
      response.error
        ? callback.reject(new Error(response.error.message))
        : callback.resolve(response.result);
    }
  };
  cdp.on("Target.receivedMessageFromTarget", listener);
  return {
    async call(method, params = {}) {
      const id = ++sequence;
      const response = new Promise((resolve, reject) =>
        pending.set(id, { resolve, reject }),
      );
      await cdp.send("Target.sendMessageToTarget", {
        sessionId,
        message: JSON.stringify({ id, method, params }),
      });
      return response;
    },
    async dispose() {
      await cdp.send("Target.detachFromTarget", { sessionId });
      cdp.off("Target.receivedMessageFromTarget", listener);
    },
  };
}
