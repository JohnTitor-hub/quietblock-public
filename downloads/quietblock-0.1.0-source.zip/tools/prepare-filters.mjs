import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { mkdir, readFile, writeFile } from "node:fs/promises";

// This package is eyeo's MV3 snapshot, including the matching diff endpoints.
const version = "1.0.103";
const integrity =
  "A/VyApwh6iV1Ycqb8xTMAujSZ/cMTOORAwznIU2csJdGZjmqZ8NWyvL7IcNlOrdFaGlhKaQ0Cfm5HvvglOQX9Q==";
const archive = `.cache/eyeo-filterlists-${version}.tgz`;
await mkdir(".cache", { recursive: true });
let data;
try {
  data = await readFile(archive);
} catch {
  const response = await fetch(
    `https://registry.npmjs.org/@eyeo/filterlists/-/filterlists-${version}.tgz`,
  );
  if (!response.ok) throw new Error(`Filter download: ${response.status}`);
  data = Buffer.from(await response.arrayBuffer());
  await writeFile(archive, data);
}
if (createHash("sha512").update(data).digest("base64") !== integrity)
  throw new Error("Filter archive integrity mismatch");
const extract = (name) =>
  execFileSync("tar", ["-xOzf", archive, `package/filterlists/${name}`], {
    maxBuffer: 30_000_000,
  }).toString();
const catalog = JSON.parse(extract("index.json"));
const available = execFileSync("tar", ["-tzf", archive]).toString().split("\n");
const regions = (
  process.argv.find((arg) => arg.startsWith("--regions="))?.split("=")[1] || ""
)
  .split(",")
  .filter(Boolean);
const ids = [
  "8C13E995-8F06-4927-BEA7-6C845FB7EEBF",
  "D72B6F06-52B2-4FED-96A2-1BF59CDD7AEC",
  "D4028CDD-3D39-4624-ACC7-8140F4EC3238",
  "0B0296EB-1CC5-49CD-AD38-8AF27420B7E4",
];
for (const region of regions) {
  const entry = catalog.find(
    (item) =>
      item.type === "ads" &&
      item.languages?.includes(region) &&
      available.includes(`package/filterlists/${item.id}`),
  );
  if (!entry) throw new Error(`No bundled regional edition for ${region}`);
  ids.push(entry.id);
}
await mkdir("filters/snapshots", { recursive: true });
const snapshots = [];
for (const id of new Set(ids)) {
  const entry = catalog.find((item) => item.id === id);
  const text = extract(id);
  const header = (name) =>
    text.match(new RegExp(`^! ${name}: (.+)$`, "mi"))?.[1];
  const path = `filters/snapshots/${id}.txt`;
  await writeFile(path, text);
  snapshots.push({
    ...entry,
    path,
    sha256: createHash("sha256").update(text).digest("hex"),
    version: Number(header("Version")),
    diff_url: header("DiffUrl"),
    expires: header("Expires"),
    license: header("Licen[cs]e") || "GPL-3.0 (eyeo filterlists package)",
    privileged: entry.type === "circumvention",
    enabled: entry.type !== "annoyances",
  });
}
await writeFile(
  "filters/lock.json",
  JSON.stringify(
    {
      package: `@eyeo/filterlists@${version}`,
      integrity: `sha512-${integrity}`,
      snapshots,
    },
    null,
    2,
  ) + "\n",
);
console.log(
  `Pinned ${snapshots.length} lists. Regional editions: ${regions.join(", ") || "English base"}.`,
);
