import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

export async function auditBuild() {
  const meta = JSON.parse(
    await readFile("artifacts/engine-metafile.json", "utf8"),
  );
  const forbidden =
    /(?:\/account\/|\/telemetry\/|\/cohorts\/|\/remote-config\/|\/cdp\/|\/sentry\.js$|\/client-ids\.js$|\/experiments\.js$|\/analytics\.js$|node_modules\/@sentry\/)/;
  const leaked = Object.keys(meta.inputs).filter((name) =>
    forbidden.test(name),
  );
  assert.deepEqual(leaked, [], "Product-service modules must not be shipped");
  const api = Object.entries(meta.outputs).find(([name]) =>
    name.endsWith("engine-api.js"),
  )[1];
  assert.equal(
    Object.keys(api.inputs).some((name) => name.includes("/isolated-heavy.")),
    false,
    "Heavy page code must not also live in the worker",
  );
  return Object.fromEntries(
    Object.entries(meta.outputs).map(([name, output]) => [name, output.bytes]),
  );
}

if (process.argv[1] === import.meta.filename)
  console.log(JSON.stringify(await auditBuild(), null, 2));
