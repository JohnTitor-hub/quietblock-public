import { build } from "esbuild";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { repairCatalogPlugin } from "./repair-catalog.mjs";

export async function buildEngine({
  source,
  outdir,
  reference = false,
  repairs,
}) {
  const sdk = path.resolve(source);
  const entryPoints = {
    "engine-api": path.join(sdk, "src/background/index.js"),
    "engine-content": path.join(sdk, "src/content/isolated/core.entry.js"),
    "engine-main": path.join(sdk, "src/content/main/snippets.entry.js"),
    "engine-heavy": path.join(
      sdk,
      "src/content/isolated/heavy-dependencies.entry.js",
    ),
  };
  const result = await build({
    entryPoints,
    outdir,
    bundle: true,
    format: "iife",
    globalName: "EWE",
    platform: "browser",
    target: "chrome127",
    minify: true,
    legalComments: "eof",
    metafile: true,
    define: { "webpackDotenvPlugin.VERSION": '"4.1.0"' },
    alias: {
      io: path.join(sdk, "src/background/io.js"),
      prefs: path.join(sdk, "src/background/prefs.js"),
      info: path.join(sdk, "src/background/info.js"),
      keepalive: path.join(sdk, "src/background/keepalive.js"),
    },
    plugins: [
      ...(repairs ? [repairCatalogPlugin(repairs)] : []),
      {
        name: "eyeo-browser",
        setup(builder) {
          builder.onResolve({ filter: /(^|\/)browser\.js$/ }, (args) => {
            if (args.importer.includes("/src/background/")) {
              return {
                path: path.resolve(
                  "node_modules/webextension-polyfill/dist/browser-polyfill.js",
                ),
              };
            }
          });
        },
      },
    ],
  });
  await mkdir("artifacts", { recursive: true });
  await writeFile(
    `artifacts/${reference ? "reference" : "engine"}-metafile.json`,
    JSON.stringify(result.metafile, null, 2),
  );
  return result.metafile;
}

if (process.argv[1] === import.meta.filename) {
  const metafile = await buildEngine({
    source: ".cache/pristine-sdk",
    outdir: ".cache/reference",
    reference: true,
  });
  console.log(
    JSON.stringify(
      Object.fromEntries(
        Object.entries(metafile.outputs).map(([name, value]) => [
          name,
          value.bytes,
        ]),
      ),
      null,
      2,
    ),
  );
}
