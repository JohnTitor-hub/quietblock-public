import { build } from "esbuild";
import { createHash } from "node:crypto";
import { cp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { copyNotices } from "./notices.mjs";
import { buildEngine } from "./build-engine.mjs";
import { makeIcons } from "./icons.mjs";
import { compileFilters } from "./compile-filters.mjs";
import { compileRepairs } from "./repair-catalog.mjs";

const laboratory = process.argv.includes("--test");
const reference = process.argv.includes("--reference");
const outdir = reference
  ? "artifacts/extension-reference"
  : laboratory
    ? "artifacts/extension-test"
    : "dist";
await rm(outdir, { recursive: true, force: true });
await mkdir(`${outdir}/rules`, { recursive: true });
await mkdir(`${outdir}/subscriptions`, { recursive: true });
const snapshots = laboratory
  ? [
      {
        id: "quietblock-lab",
        title: "Detector laboratory",
        type: "circumvention",
        url: "https://filters.quietblock.test/laboratory.txt",
        diff_url: "https://filters.quietblock.test/laboratory-diff.json",
        expires: "1 days",
        enabled: true,
        privileged: true,
        languages: [],
        path: "tests/fixtures/laboratory.txt",
      },
    ]
  : JSON.parse(await readFile("filters/lock.json", "utf8")).snapshots;
const subscriptions = [];
const reports = [];
for (const snapshot of snapshots) {
  const content = await readFile(snapshot.path, "utf8");
  if (
    snapshot.sha256 &&
    createHash("sha256").update(content).digest("hex") !== snapshot.sha256
  )
    throw new Error(`Snapshot digest mismatch: ${snapshot.title}`);
  const { rules, sourceMap, report } = await compileFilters(content);
  if (laboratory && report.rejected.length)
    throw new Error(JSON.stringify(report.rejected));
  const regexRules = rules.filter((rule) => rule.condition.regexFilter).length;
  if (regexRules > 1000)
    throw new Error(`Regex quota exceeded: ${snapshot.title}`);
  subscriptions.push({ ...snapshot, rule_count: rules.length });
  reports.push({
    id: snapshot.id,
    title: snapshot.title,
    rules: rules.length,
    regexRules,
    ...report,
  });
  await writeFile(`${outdir}/rules/${snapshot.id}.json`, JSON.stringify(rules));
  await writeFile(
    `${outdir}/rules/${snapshot.id}.json.map`,
    JSON.stringify(sourceMap),
  );
  await writeFile(`${outdir}/subscriptions/${snapshot.id}`, content);
}
const engineMeta = await buildEngine({
  source: reference ? ".cache/pristine-sdk" : "vendor/eyeo-sdk",
  outdir,
  reference,
  ...(!reference ? { repairs: await compileRepairs(snapshots) } : {}),
});
const app = await build({
  entryPoints: ["src/background.ts"],
  outfile: `${outdir}/app.js`,
  bundle: true,
  minify: true,
  target: "chrome127",
  format: "iife",
  metafile: true,
  define: {
    BUNDLED_SUBSCRIPTIONS: JSON.stringify(subscriptions),
    REFERENCE_ENGINE: JSON.stringify(reference),
  },
});
await writeFile(
  `artifacts/${reference ? "reference" : "app"}-app-metafile.json`,
  JSON.stringify(app.metafile, null, 2),
);
await writeFile(
  `${outdir}/background.js`,
  'importScripts("engine-api.js", "app.js");\n',
);
await makeIcons(outdir);
const manifest = JSON.parse(await readFile("src/manifest.json", "utf8"));
manifest.declarative_net_request = {
  rule_resources: subscriptions.map((s) => ({
    id: s.id,
    enabled: s.enabled,
    path: `rules/${s.id}.json`,
  })),
};
await writeFile(`${outdir}/manifest.json`, JSON.stringify(manifest, null, 2));
if (laboratory)
  await writeFile(
    `${outdir}/test-control.html`,
    "<!doctype html><title>Test controls</title>",
  );
await build({
  entryPoints: ["ui/popup.ts", "ui/options.ts"],
  outdir,
  bundle: true,
  minify: true,
  target: "chrome127",
  format: "esm",
});
for (const asset of [
  "popup.html",
  "options.html",
  "privacy.html",
  "style.css",
  "mark.svg",
])
  await cp(`ui/${asset}`, `${outdir}/${asset}`);
await cp("LICENSE", `${outdir}/LICENSE`);
await copyNotices(outdir, engineMeta, reference);
await cp("THIRD_PARTY_NOTICES.md", `${outdir}/THIRD_PARTY_NOTICES.md`);
await writeFile(
  `artifacts/${laboratory ? "lab" : "production"}-conversion.json`,
  JSON.stringify(reports, null, 2),
);
console.log(
  `Built ${outdir}: ${reports.reduce((n, r) => n + r.rules, 0)} network rules; ${reports.reduce((n, r) => n + r.content, 0)} content rules; ${reports.reduce((n, r) => n + r.rejected.length, 0)} reported conversion gaps.`,
);
