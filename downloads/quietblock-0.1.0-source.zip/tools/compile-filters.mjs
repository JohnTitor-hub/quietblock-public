import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const {
  isRegexSupported,
} = require("@eyeo/abp2dnr/build/Release/isRegexSupported.node");
const {
  createConverter,
} = require("../vendor/eyeo-sdk/adblockpluscore/lib/dnr/index.js");
const {
  Filter,
} = require("../vendor/eyeo-sdk/adblockpluscore/lib/filterClasses.js");
const {
  normalize,
} = require("../vendor/eyeo-sdk/adblockpluscore/lib/filters/index.js");

export async function compileFilters(content) {
  const rules = [];
  const sourceMap = [];
  const report = { network: 0, content: 0, ignored: 0, rejected: [] };
  let nextId = 1;
  const convert = createConverter({
    isRegexSupported: (options) => isRegexSupported(options).isSupported,
    modifyRule(rule) {
      return { ...rule, id: nextId++ };
    },
  });
  for (const original of content.split(/\r?\n/)) {
    const text = normalize(original);
    if (!text || text.startsWith("!") || text.startsWith("[")) {
      report.ignored++;
      continue;
    }
    const filter = Filter.fromText(text);
    if (filter.type === "invalid") {
      report.rejected.push({ text, reason: filter.reason });
      continue;
    }
    if (!["blocking", "allowing"].includes(filter.type)) {
      report.content++;
      continue;
    }
    const converted = await convert(text);
    if (converted instanceof Error) {
      report.rejected.push({ text, reason: converted.message });
      continue;
    }
    sourceMap.push([text, converted.map((rule) => rule.id)]);
    rules.push(...converted);
    report.network++;
  }
  return { rules, sourceMap, report };
}
