import { spawn, execFileSync } from "node:child_process";
import { EventEmitter, once } from "node:events";
import { mkdir, readFile, rm } from "node:fs/promises";
import path from "node:path";
import { attachTarget } from "./cdp.mjs";

export const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export async function until(read, description) {
  const deadline = performance.now() + 30_000;
  do {
    const value = await read();
    if (value) return value;
    await pause(100);
  } while (performance.now() < deadline);
  throw new Error(`Timed out: ${description}`);
}

// No automation client attaches to extension workers; idle measurements must
// not accidentally keep the process being measured alive through debugging.
export async function launchChrome(
  profile,
  headed = false,
  { freezeLists = true } = {},
) {
  await mkdir(profile, { recursive: true });
  await rm(path.join(profile, "DevToolsActivePort"), { force: true });
  const child = spawn(
    process.env.CHROME_PATH ||
      "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    [
      `--user-data-dir=${path.resolve(profile)}`,
      "--remote-debugging-port=0",
      "--enable-unsafe-extension-debugging",
      "--no-first-run",
      "--no-default-browser-check",
      "--disable-background-networking",
      "--disable-component-update",
      "--disable-sync",
      "--window-size=1365,900",
      `--host-resolver-rules=MAP *.quietblock.test 127.0.0.1, MAP ad.doubleclick.net 127.0.0.1${freezeLists ? ", MAP easylist-downloads.adblockplus.org ~NOTFOUND" : ""}`,
      ...(headed ? [] : ["--headless=new"]),
      "about:blank",
    ],
    { stdio: "ignore" },
  );
  const exited = once(child, "exit");
  const portFile = path.join(profile, "DevToolsActivePort");
  const [port, endpoint] = await until(async () => {
    try {
      return (await readFile(portFile, "utf8")).trim().split("\n");
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
  }, "Chrome debugging endpoint");
  const socket = new WebSocket(`ws://127.0.0.1:${port}${endpoint}`);
  await new Promise((resolve, reject) => {
    socket.addEventListener("open", resolve, { once: true });
    socket.addEventListener("error", reject, { once: true });
  });
  const browser = new EventEmitter();
  // At most 30 page sessions plus the worker in a separate profiling run.
  browser.setMaxListeners(32);
  let sequence = 0;
  const pending = new Map();
  socket.addEventListener("message", ({ data }) => {
    const message = JSON.parse(data);
    if (message.method) browser.emit(message.method, message.params);
    const callback = pending.get(message.id);
    if (callback) {
      pending.delete(message.id);
      clearTimeout(callback.timer);
      if (message.error) callback.reject(new Error(message.error.message));
      else callback.resolve(message.result);
    }
  });
  socket.addEventListener("close", () => {
    for (const callback of pending.values()) {
      clearTimeout(callback.timer);
      callback.reject(new Error("Chrome connection closed"));
    }
    pending.clear();
  });
  browser.send = (method, params = {}) => {
    const id = ++sequence;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        pending.delete(id);
        reject(new Error(`CDP timed out: ${method}`));
      }, 30_000);
      pending.set(id, { resolve, reject, timer });
      socket.send(JSON.stringify({ id, method, params }));
    });
  };
  return {
    browser,
    async close() {
      await browser.send("Browser.close").catch(() => {});
      await exited;
    },
  };
}

export async function evaluate(channel, expression) {
  const result = await channel.call("Runtime.evaluate", {
    expression,
    awaitPromise: true,
    returnByValue: true,
  });
  if (result.exceptionDetails)
    throw new Error(JSON.stringify(result.exceptionDetails));
  return result.result.value;
}

export async function openPage(browser, url) {
  const requested = new URL(url);
  const { targetId } = await browser.send("Target.createTarget", { url });
  let loaded = 0;
  const channel = await attachTarget(browser, targetId, (event) => {
    if (event.method === "Page.loadEventFired") loaded++;
  });
  await channel.call("Page.enable");
  await until(
    () =>
      evaluate(
        channel,
        `location.protocol === ${JSON.stringify(requested.protocol)} && location.host === ${JSON.stringify(requested.host)} && location.pathname === ${JSON.stringify(requested.pathname)} && document.readyState === "complete"`,
      ),
    `page load: ${url}`,
  );
  return {
    targetId,
    channel,
    async reload() {
      const previous = loaded;
      await channel.call("Page.reload");
      await until(() => loaded > previous, "warm page reload");
    },
  };
}

export async function loadExtension(browser, root) {
  const manifest = JSON.parse(await readFile(`${root}/manifest.json`, "utf8"));
  const { id } = await browser.send("Extensions.loadUnpacked", {
    path: path.resolve(root),
  });
  const options = manifest.options_ui?.page || manifest.options_page;
  const page = await openPage(browser, `chrome-extension://${id}/${options}`);
  const quietblock = manifest.name === "Quietblock";
  const ubol = id === "ddkjiahejlhfcafbddmgiahcphecmpfh";
  const config = await until(
    () =>
      evaluate(
        page.channel,
        `(async () => {
          const state = ${quietblock} ? await chrome.runtime.sendMessage({channel:'quietblock',command:'status'}).catch(() => null) : null;
          const reference = ${ubol} ? await chrome.runtime.sendMessage({what:'getOptionsPageData'}).catch(() => null) : null;
          const stored = await chrome.storage.local.get(null);
          const rulesets = await chrome.declarativeNetRequest.getEnabledRulesets();
          if (${quietblock} ? !state?.ok : !rulesets.length || (${ubol} && !reference)) return null;
          return {rulesets, settings: state?.value?.settings || null,
            lists: state?.value?.lists.map(({url,version,enabled}) => ({url,version,enabled})),
            filteringMode: reference?.defaultFilteringMode ?? stored.filteringModeDetails ?? null,
            hasBroadHostPermissions: reference?.hasOmnipotence ?? null};
        })()`,
      ),
    "extension readiness",
  );
  await page.channel.dispose();
  await browser.send("Target.closeTarget", { targetId: page.targetId });
  return { id, version: manifest.version, config };
}

// rusage_info_v0 layout from the macOS SDK's sys/resource.h. This sums physical
// footprint over the Chrome instance; RSS is secondary and repeats shared pages.
export function memory(processes) {
  const program = `import ctypes,ctypes.util,json,sys
class Usage(ctypes.Structure):
 _fields_=[('uuid',ctypes.c_ubyte*16)]+[(name,ctypes.c_uint64) for name in ['user','system','idle','interrupt','pageins','wired','resident','footprint','start','exit']]
lib=ctypes.CDLL(ctypes.util.find_library('proc'))
lib.proc_pid_rusage.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_void_p]
rows=[]
for pid in map(int,sys.argv[1:]):
 value=Usage()
 if lib.proc_pid_rusage(pid,0,ctypes.byref(value))==0:rows.append(value)
print(json.dumps({'rssKiB':sum(row.resident for row in rows)/1024,'footprintBytes':sum(row.footprint for row in rows),'readProcesses':len(rows),'listedProcesses':len(sys.argv)-1}))`;
  return JSON.parse(
    execFileSync(
      "python3",
      ["-c", program, ...processes.map((p) => String(p.id))],
      {
        encoding: "utf8",
      },
    ),
  );
}

export async function measure(browser, work, minimumSeconds = 0) {
  let processes = (await browser.send("SystemInfo.getProcessInfo")).processInfo;
  const previous = new Map(processes.map((p) => [p.id, p.cpuTime]));
  const samples = [];
  const start = performance.now();
  let done = false,
    failure,
    cpuSeconds = 0,
    workMs;
  const running = work().then(
    () => {
      workMs = performance.now() - start;
      done = true;
    },
    (error) => {
      failure = error;
      done = true;
    },
  );
  do {
    await pause(1000);
    processes = (await browser.send("SystemInfo.getProcessInfo")).processInfo;
    for (const proc of processes) {
      cpuSeconds += Math.max(0, proc.cpuTime - (previous.get(proc.id) || 0));
      previous.set(proc.id, proc.cpuTime);
    }
    samples.push({
      elapsedSeconds: (performance.now() - start) / 1000,
      ...memory(processes),
    });
  } while (!done || performance.now() - start < minimumSeconds * 1000);
  await running;
  if (failure) throw failure;
  return {
    cpuSeconds,
    workMs,
    wallSeconds: (performance.now() - start) / 1000,
    peakFootprintBytes: Math.max(...samples.map((s) => s.footprintBytes)),
    endFootprintBytes: samples.at(-1).footprintBytes,
    samples,
  };
}
