import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { createRequire } from "node:module";
import main from "@eyeo/snippets/main";
import isolated from "@eyeo/snippets/isolated/lite";
import heavy from "@eyeo/snippets/isolated/heavy";

const require = createRequire(import.meta.url);
const {
  Filter,
} = require("../vendor/eyeo-sdk/adblockpluscore/lib/filterClasses.js");
const {
  parseScript,
} = require("../vendor/eyeo-sdk/adblockpluscore/lib/scriptParsing.js");

export async function compileRepairs(snapshots) {
  const rules = [];
  const commands = [];
  const bodies = new Map();
  const texts = new Map();
  for (const snapshot of snapshots.filter((item) => item.privileged)) {
    const content = await readFile(snapshot.path, "utf8");
    for (const text of content.split(/\r?\n/)) {
      const filter = Filter.fromText(Filter.normalize(text));
      if (filter.type !== "snippet") continue;
      const parsed = parseScript(filter.body);
      for (const [name] of parsed) {
        if (![main, isolated, heavy].some((library) => library.has(name)))
          throw new Error(`Unpackaged repair operation: ${name}`);
      }
      const body = JSON.stringify(parsed);
      if (!bodies.has(body)) {
        bodies.set(body, commands.length);
        commands.push(parsed);
      }
      if (texts.has(filter.text)) {
        const row = rules[texts.get(filter.text)];
        if (!row[1].includes(snapshot.url)) row[1].push(snapshot.url);
      } else {
        texts.set(filter.text, rules.length);
        rules.push([filter.text, [snapshot.url], bodies.get(body)]);
      }
    }
  }
  const version = createHash("sha256")
    .update(JSON.stringify({ rules, commands }))
    .digest("hex");
  return { version, rules, commands };
}

export function repairCatalogPlugin(catalog) {
  const exports = {
    repairCatalog: {
      version: catalog.version,
      bodies: catalog.rules.map((row) => row[2]),
    },
    bundledRepairRules: catalog.rules,
    allRepairCommands: catalog.commands,
    ...Object.fromEntries(
      [
        ["mainRepairCommands", main],
        ["isolatedRepairCommands", isolated],
        ["heavyRepairCommands", heavy],
      ].map(([name, library]) => [
        name,
        catalog.commands.map((body) =>
          body.map((command) => (library.has(command[0]) ? command : null)),
        ),
      ]),
    ),
  };
  return {
    name: "bundled-repairs",
    setup(builder) {
      builder.onResolve({ filter: /^#quietblock\/repairs$/ }, () => ({
        path: "catalog",
        namespace: "bundled-repairs",
      }));
      builder.onLoad({ filter: /.*/, namespace: "bundled-repairs" }, () => ({
        contents: Object.entries(exports)
          .map(
            ([name, value]) =>
              `export const ${name} = ${JSON.stringify(value)};`,
          )
          .join("\n"),
        loader: "js",
      }));
    },
  };
}
