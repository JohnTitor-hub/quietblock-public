import { test, expect } from "./fixtures.mjs";
import { mkdir, readFile } from "node:fs/promises";
const productionRoot = process.env.QUIETBLOCK_REFERENCE
  ? "artifacts/extension-reference"
  : process.env.QUIETBLOCK_EXTENSION || "dist";
test.use({ extensionPath: productionRoot });

test("real lists load, block network and cosmetic ads, and emit only functional filter update requests", async ({
  extension,
  laboratory,
}) => {
  const outbound = [];
  let malformed = false;
  await extension.context.route("https://**/*", (route) => {
    outbound.push(route.request().url());
    return route.fulfill({
      status: 200,
      contentType: "application/json",
      headers: { date: new Date().toUTCString() },
      body: malformed
        ? "{invalid JSON"
        : JSON.stringify({
            filters: route.request().url().includes("/diff/easylist/")
              ? {
                  add: ["||delta.quietblock.test^*/delta.js$script"],
                  remove: ["||ad.doubleclick.net^"],
                }
              : { add: [], remove: [] },
          }),
    });
  });
  const control = await extension.context.newPage();
  await control.goto(`chrome-extension://${extension.id}/options.html`);
  const state = await control.evaluate(
    async () =>
      (
        await chrome.runtime.sendMessage({
          channel: "quietblock",
          command: "status",
        })
      ).value,
  );
  expect(state.catalog).toHaveLength(4);
  expect(state.settings.enabledLists).toHaveLength(3);
  expect(
    state.catalog.find((item) => item.type === "circumvention").privileged,
  ).toBe(true);
  expect(state.catalog.some((item) => item.type === "allowing")).toBe(false);
  expect(
    await extension.worker.evaluate(() =>
      chrome.declarativeNetRequest.getEnabledRulesets(),
    ),
  ).toHaveLength(3);
  const page = await extension.context.newPage();
  await page.goto(`${laboratory.url}/production`);
  await expect(page.locator("h1")).toBeVisible();
  await expect(page.locator("p")).toBeVisible();
  await expect(page.locator(".ad-banner-300")).toBeHidden();
  expect(
    laboratory.requests.some((request) => request.path === "/advertisement.js"),
  ).toBe(false);
  if (!process.env.QUIETBLOCK_REFERENCE) {
    const cdp = await extension.context.newCDPSession(control);
    await cdp.send("ServiceWorker.enable");
    await cdp.send("ServiceWorker.stopAllWorkers");
    await control.evaluate(() =>
      chrome.runtime.sendMessage({ channel: "quietblock", command: "update" }),
    );
    await expect.poll(() => outbound.length).toBeGreaterThanOrEqual(3);
    for (const request of outbound) {
      const url = new URL(request);
      expect(url.hostname).toBe("easylist-downloads.adblockplus.org");
      expect(url.pathname).toContain("/v3/diff/");
      expect([...url.searchParams.keys()]).toEqual(["lastVersion"]);
    }
    await expect
      .poll(() =>
        control.evaluate(async () =>
          (
            await chrome.runtime.sendMessage({
              channel: "quietblock",
              command: "status",
            })
          ).value.lists.every((list) => !list.downloading),
        ),
      )
      .toBe(true);
    await expect
      .poll(() =>
        control.evaluate(async () =>
          (await chrome.declarativeNetRequest.getDynamicRules()).some((rule) =>
            rule.condition.urlFilter?.includes("delta.js"),
          ),
        ),
      )
      .toBe(true);
    const ruleMap = JSON.parse(
      await readFile(
        `${productionRoot}/rules/8C13E995-8F06-4927-BEA7-6C845FB7EEBF.json.map`,
        "utf8",
      ),
    );
    const ids = ruleMap.find(([text]) => text === "||ad.doubleclick.net^")[1];
    expect(
      await control.evaluate(() =>
        chrome.declarativeNetRequest.getDisabledRuleIds({
          rulesetId: "8C13E995-8F06-4927-BEA7-6C845FB7EEBF",
        }),
      ),
    ).toEqual(expect.arrayContaining(ids));
    malformed = true;
    await control.evaluate(() =>
      chrome.runtime.sendMessage({ channel: "quietblock", command: "update" }),
    );
    await expect
      .poll(() =>
        control.evaluate(async () =>
          (
            await chrome.runtime.sendMessage({
              channel: "quietblock",
              command: "status",
            })
          ).value.lists.every(
            (list) => list.downloadStatus === "synchronize_invalid_data",
          ),
        ),
      )
      .toBe(true);
    expect(
      await control.evaluate(async () =>
        (await chrome.declarativeNetRequest.getDynamicRules()).some((rule) =>
          rule.condition.urlFilter?.includes("delta.js"),
        ),
      ),
    ).toBe(true);
    expect(extension.errors).toEqual([]);
    await mkdir("artifacts/screenshots", { recursive: true });
    await control.setViewportSize({ width: 1000, height: 1600 });
    await control.screenshot({
      path: "artifacts/screenshots/settings-production.png",
      fullPage: true,
    });
  }
});
