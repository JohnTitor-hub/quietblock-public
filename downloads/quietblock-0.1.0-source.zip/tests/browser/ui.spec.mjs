import { test, expect } from "./fixtures.mjs";
import { mkdir, writeFile } from "node:fs/promises";

test("settings save, validate, export, and import with keyboard-friendly native controls", async ({
  extension,
}) => {
  const page = await extension.context.newPage();
  await page.goto(`chrome-extension://${extension.id}/options.html`);
  await expect(
    page.getByRole("heading", { name: "A quieter page." }),
  ).toBeVisible();
  const policyPage = extension.context.waitForEvent("page");
  await page.getByRole("link", { name: "Privacy policy" }).click();
  const policy = await policyPage;
  await expect(
    policy.getByRole("heading", { name: "Privacy policy", exact: true }),
  ).toBeVisible();
  await expect(
    policy.getByRole("heading", { name: "Limited Use and disclosure" }),
  ).toBeVisible();
  await expect(policy.locator("body")).toContainText("session storage");
  expect(await policy.locator("script").count()).toBe(0);
  await policy.close();
  const sites = page.getByRole("textbox", {
    name: "Paused sites, one hostname per line",
  });
  await sites.fill("example.com");
  await page.getByRole("button", { name: "Save changes" }).click();
  await expect(
    page.getByRole("status").filter({ hasText: "Saved. Reload" }),
  ).toBeVisible();
  await page.reload();
  await expect(sites).toHaveValue("example.com");
  const rules = page.getByRole("textbox", { name: "Custom filter rules" });
  await rules.fill("/(abc)\\1/$script");
  await page.getByRole("button", { name: "Save changes" }).click();
  await expect(page.getByRole("alert")).toContainText(
    "Invalid or unsupported filter",
  );
  const downloadPromise = page.waitForEvent("download");
  await page.getByRole("button", { name: "Export settings" }).click();
  const download = await downloadPromise;
  expect(download.suggestedFilename()).toBe("quietblock-settings.json");
  const settings = await page.evaluate(
    async () =>
      (
        await chrome.runtime.sendMessage({
          channel: "quietblock",
          command: "status",
        })
      ).value.settings,
  );
  await page.getByLabel("Import settings", { exact: true }).setInputFiles({
    name: "settings.json",
    mimeType: "application/json",
    buffer: Buffer.from(
      JSON.stringify({
        ...settings,
        pausedHosts: ["imported.example"],
        customFilters: [],
      }),
    ),
  });
  await expect(sites).toHaveValue("imported.example");
  await expect(rules).toHaveValue("");
  await page.getByLabel("Import settings", { exact: true }).setInputFiles({
    name: "invalid.json",
    mimeType: "application/json",
    buffer: Buffer.from('{"schema":999}'),
  });
  await expect(page.getByRole("alert")).toContainText(
    "Unsupported settings version",
  );
  await page.reload();
  await expect(sites).toHaveValue("imported.example");
  await mkdir("artifacts/screenshots", { recursive: true });
  await page.setViewportSize({ width: 1280, height: 1600 });
  await page.screenshot({
    path: "artifacts/screenshots/settings-desktop.png",
    fullPage: true,
  });
  await page.setViewportSize({ width: 360, height: 800 });
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
  await page.screenshot({
    path: "artifacts/screenshots/settings-mobile.png",
    fullPage: true,
  });
  const unlabeled = await page
    .locator("input,textarea")
    .evaluateAll((nodes) =>
      nodes
        .filter(
          (node) => !node.labels?.length && !node.getAttribute("aria-label"),
        )
        .map((node) => node.id),
    );
  expect(unlabeled).toEqual([]);
  await page.keyboard.press("Tab");
  expect(
    await page.evaluate(() => document.activeElement !== document.body),
  ).toBe(true);
  expect(extension.errors).toEqual([]);
});

test("actual toolbar popup pauses and resumes the current site", async ({
  extension,
  laboratory,
}) => {
  const page = await extension.context.newPage();
  await page.goto(laboratory.url);
  await page.bringToFront();
  const cdp = await extension.context.newCDPSession(page);
  const open = async () => {
    await extension.worker.evaluate(() => chrome.action.openPopup());
    let target;
    await expect
      .poll(async () => {
        target = (await cdp.send("Target.getTargets")).targetInfos.find(
          (item) =>
            item.url === `chrome-extension://${extension.id}/popup.html`,
        );
        return Boolean(target);
      })
      .toBe(true);
    const { sessionId } = await cdp.send("Target.attachToTarget", {
      targetId: target.targetId,
      flatten: false,
    });
    let sequence = 0;
    const pending = new Map();
    const listener = (event) => {
      if (event.sessionId !== sessionId) return;
      const response = JSON.parse(event.message);
      const callback = pending.get(response.id);
      if (callback) {
        pending.delete(response.id);
        response.error
          ? callback.reject(new Error(response.error.message))
          : callback.resolve(response.result);
      }
    };
    cdp.on("Target.receivedMessageFromTarget", listener);
    const call = async (method, params = {}) => {
      const id = ++sequence;
      const promise = new Promise((resolve, reject) =>
        pending.set(id, { resolve, reject }),
      );
      await cdp.send("Target.sendMessageToTarget", {
        sessionId,
        message: JSON.stringify({ id, method, params }),
      });
      return promise;
    };
    const read = async (expression) =>
      (
        await call("Runtime.evaluate", {
          expression,
          returnByValue: true,
          awaitPromise: true,
        })
      ).result.value;
    const screenshot = async (path) =>
      writeFile(
        path,
        Buffer.from((await call("Page.captureScreenshot")).data, "base64"),
      );
    return {
      read,
      screenshot,
      dispose: () => cdp.off("Target.receivedMessageFromTarget", listener),
    };
  };
  let popup = await open();
  await expect
    .poll(() => popup.read('document.querySelector("#protection").textContent'))
    .toBe("Protection on");
  expect(await popup.read('document.querySelector("#site").textContent')).toBe(
    "lab.quietblock.test",
  );
  await mkdir("artifacts/screenshots", { recursive: true });
  await popup.screenshot("artifacts/screenshots/popup-active.png");
  await popup.read('document.querySelector("#toggle").click()');
  await expect(page.locator(".sponsored")).toBeVisible();
  popup.dispose();
  popup = await open();
  await expect
    .poll(() => popup.read('document.querySelector("#protection").textContent'))
    .toBe("Protection paused");
  await popup.screenshot("artifacts/screenshots/popup-paused.png");
  await popup.read('document.querySelector("#toggle").click()');
  await expect(page.locator(".sponsored")).toBeHidden();
  popup.dispose();
  expect(extension.errors).toEqual([]);
});

test("a stale settings page preserves a newer site pause and keeps unsaved edits", async ({
  extension,
}) => {
  const page = await extension.context.newPage();
  await page.goto(`chrome-extension://${extension.id}/options.html`);
  await expect(
    page.getByRole("status").filter({ hasText: "Loading settings" }),
  ).toHaveCount(0);
  await page.evaluate(() =>
    chrome.runtime.sendMessage({
      channel: "quietblock",
      command: "pause",
      host: "newer.example",
      paused: true,
    }),
  );
  const rules = page.getByRole("textbox", { name: "Custom filter rules" });
  await rules.fill("example.com##.ad");
  await page.getByRole("button", { name: "Save changes" }).click();
  await expect(page.getByRole("alert")).toContainText(
    "Settings changed elsewhere",
  );
  await expect(rules).toHaveValue("example.com##.ad");
  const settings = await page.evaluate(
    async () =>
      (
        await chrome.runtime.sendMessage({
          channel: "quietblock",
          command: "status",
        })
      ).value.settings,
  );
  expect(settings.pausedHosts).toContain("newer.example");
  expect(settings.customFilters).toEqual([]);
});
