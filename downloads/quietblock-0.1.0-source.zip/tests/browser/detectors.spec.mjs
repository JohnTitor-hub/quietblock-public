import { test, expect } from "./fixtures.mjs";

test("early property/function repairs and fetch rewriting work, while negative controls remain detectable", async ({
  extension,
  laboratory,
}) => {
  const page = await extension.context.newPage();
  await page.goto(`${laboratory.url}/detectors`);
  await expect
    .poll(() =>
      page
        .evaluate(() => window.earlyDetector)
        .catch((error) => {
          if (error.message.includes("Execution context was destroyed"))
            return null;
          throw error;
        }),
    )
    .toEqual({ ready: true, blocked: false });
  await expect
    .poll(() => page.evaluate(() => window.fetchResult))
    .toEqual({ ads: false, content: "kept" });
  await expect(page.locator("section")).toBeHidden();
  await expect(page.locator(".harmless-bait")).toBeVisible();
  await expect
    .poll(() => page.evaluate(() => window.workerResult))
    .toEqual({ ads: true, property: "undefined" });
  await expect
    .poll(() => page.evaluate(() => window.integrityPassed))
    .toBe(false);
  expect(
    await page
      .locator(".sponsored")
      .evaluate((node) => getComputedStyle(node).display),
  ).toBe("none");
  expect(
    await page.evaluate(
      () =>
        Object.getOwnPropertyDescriptor(window, "adCheck").get !== undefined,
    ),
  ).toBe(true);
  expect(
    laboratory.requests.some((request) => request.path === "/fetch.json"),
  ).toBe(true);
  const before = laboratory.requests.filter(
    (request) => request.path === "/detectors",
  ).length;
  await page.reload();
  await expect
    .poll(() =>
      page
        .evaluate(() => window.earlyDetector)
        .catch((error) => {
          if (error.message.includes("Execution context was destroyed"))
            return null;
          throw error;
        }),
    )
    .toEqual({ ready: true, blocked: false });
  expect(
    laboratory.requests.filter((request) => request.path === "/detectors")
      .length - before,
  ).toBe(1);
  await page.evaluate(() => {
    history.pushState({}, "", "/spa");
    document.body.insertAdjacentHTML(
      "beforeend",
      "<section id='new-ad'>Sponsor reinserted</section>",
    );
  });
  await expect(page.locator("#new-ad")).toBeHidden();
});

test("CSP, frame inheritance, and on-demand heavy XPath filtering survive the reduced host", async ({
  extension,
  laboratory,
}) => {
  const page = await extension.context.newPage();
  await page.goto(`${laboratory.url}/strict`);
  await expect
    .poll(() =>
      page
        .evaluate(() => window.earlyDetector)
        .catch((error) => {
          if (error.message.includes("Execution context was destroyed"))
            return null;
          throw error;
        }),
    )
    .toEqual({ ready: true, blocked: false });
  await expect(page.locator(".sponsored")).toBeHidden();
  await page.goto(`${laboratory.url}/frames`);
  for (const name of ["same", "cross"])
    await expect(
      page.frameLocator(`#${name}`).locator(".sponsored"),
    ).toBeHidden();
  await expect(page.frameLocator("#sandbox").locator("p")).toBeVisible();
  const control = await extension.context.newPage();
  await control.goto(`chrome-extension://${extension.id}/test-control.html`);
  await control.evaluate(() =>
    chrome.runtime.sendMessage({
      channel: "quietblock",
      command: "pause",
      host: "lab.quietblock.test",
      paused: true,
    }),
  );
  await page.reload();
  for (const name of ["same", "cross"]) {
    await expect(
      page.frameLocator(`#${name}`).locator(".sponsored"),
    ).toBeVisible();
    expect(
      await page
        .frameLocator(`#${name}`)
        .locator("body")
        .evaluate(() => window.adBlocked),
    ).toBe(true);
  }
  await page.goto(`${laboratory.url.replace("lab.", "heavy.")}/heavy`);
  await expect(page.locator("#heavy-ad")).toBeHidden();
  await expect(page.locator("h1")).toBeVisible();
  expect(extension.errors).toEqual([]);
});

test("cache can be disabled per site without a reload loop", async ({
  extension,
  laboratory,
}) => {
  const control = await extension.context.newPage();
  await control.goto(`chrome-extension://${extension.id}/test-control.html`);
  await control.evaluate(async () => {
    const { value } = await chrome.runtime.sendMessage({
      channel: "quietblock",
      command: "status",
    });
    await chrome.runtime.sendMessage({
      channel: "quietblock",
      command: "save",
      settings: {
        ...value.settings,
        snippetCacheDisabledHosts: ["lab.quietblock.test"],
      },
    });
  });
  const page = await extension.context.newPage();
  await page.goto(laboratory.url);
  await expect.poll(() => page.evaluate(() => window.adBlocked)).toBe(false);
  expect(
    laboratory.requests.filter((request) => request.path === "/").length,
  ).toBe(1);
  expect(
    await page.evaluate(() => sessionStorage.getItem("qb-filters-config")),
  ).toBeNull();
  expect(extension.errors).toEqual([]);
});
