import { test, expect } from "./fixtures.mjs";

test("real Chrome engine blocks requests, preserves exceptions, and applies page filters", async ({
  extension,
  laboratory,
}) => {
  const page = await extension.context.newPage();
  await page.goto(laboratory.url);
  await expect(page.locator("h1")).toBeVisible();
  await expect(page.locator(".sponsored")).toBeHidden();
  await expect(page.locator("article")).toBeHidden();
  await expect(page.locator(".harmless-bait")).toBeVisible();
  await expect
    .poll(() =>
      page.evaluate(() => ({
        ad: Boolean(window.adLoaded),
        allowed: window.allowedLoaded,
        detector: window.adBlocked,
        stub: window.stubLoaded,
      })),
    )
    .toEqual({ ad: false, allowed: true, detector: false, stub: true });
  expect(laboratory.requests.some((request) => request.path === "/ad.js")).toBe(
    false,
  );
  expect(
    laboratory.requests.some((request) => request.path === "/stub.js"),
  ).toBe(false);
  expect(extension.errors).toEqual([]);
});

test("user request exceptions preserve page filtering while document exceptions pause it", async ({
  extension,
  laboratory,
}) => {
  const options = await extension.context.newPage();
  await options.goto(`chrome-extension://${extension.id}/options.html`);
  const rules = options.getByRole("textbox", { name: "Custom filter rules" });
  await expect(rules).toBeEnabled();
  const page = await extension.context.newPage();
  await page.goto(laboratory.url);
  await expect
    .poll(() =>
      page
        .evaluate(() => ({
          ad: Boolean(window.adLoaded),
          allowed: window.allowedLoaded,
          detector: window.adBlocked,
        }))
        .catch((error) => {
          if (error.message.includes("Execution context was destroyed"))
            return null;
          throw error;
        }),
    )
    .toEqual({ ad: false, allowed: true, detector: false });

  for (const [rule, paused] of [
    ["@@||ads.quietblock.test^", false],
    ["@@||lab.quietblock.test^$document", true],
  ]) {
    await rules.fill(rule);
    await options.getByRole("button", { name: "Save changes" }).click();
    await expect(
      options.getByRole("status").filter({ hasText: "Saved. Reload" }),
    ).toBeVisible();
    await page.reload();
    await expect.poll(() => page.evaluate(() => window.adLoaded)).toBe(true);
    await expect(page.locator(".sponsored")).toBeVisible({ visible: paused });
    await expect.poll(() => page.evaluate(() => window.adBlocked)).toBe(paused);
  }
  await options.reload();
  await expect(rules).toHaveValue("@@||lab.quietblock.test^$document");
  expect(extension.errors).toEqual([]);
});
