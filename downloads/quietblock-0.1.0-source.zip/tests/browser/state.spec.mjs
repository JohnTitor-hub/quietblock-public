import { test, expect } from "./fixtures.mjs";

test("settings apply every filtering layer, reject failures, and recover after worker termination", async ({
  extension,
  laboratory,
}) => {
  const control = await extension.context.newPage();
  await control.goto(`chrome-extension://${extension.id}/test-control.html`);
  const command = (command, extra = {}) =>
    control.evaluate(
      (message) =>
        chrome.runtime.sendMessage({ channel: "quietblock", ...message }),
      { command, ...extra },
    );
  const initial = await command("status");
  expect(initial.ok).toBe(true);
  const alarm = await extension.worker.evaluate(() =>
    chrome.alarms.get("quietblock.updates"),
  );
  const page = await extension.context.newPage();
  await page.goto(laboratory.url);
  await expect(page.locator(".sponsored")).toBeHidden();
  expect(
    (await command("pause", { host: "lab.quietblock.test", paused: true })).ok,
  ).toBe(true);
  await page.reload();
  await expect(page.locator(".sponsored")).toBeVisible();
  await expect(page.locator("article")).toBeVisible();
  expect(
    await page.evaluate(() => ({
      ad: window.adLoaded,
      detector: window.adBlocked,
    })),
  ).toEqual({ ad: true, detector: true });
  await command("pause", { host: "lab.quietblock.test", paused: false });
  await page.reload();
  await expect(page.locator(".sponsored")).toBeHidden();
  await expect.poll(() => page.evaluate(() => window.adBlocked)).toBe(false);
  const saved = await command("save", {
    settings: {
      ...initial.value.settings,
      customFilters: ["lab.quietblock.test## p"],
    },
  });
  expect(saved.ok).toBe(true);
  expect((await command("save", { settings: saved.value.settings })).ok).toBe(
    true,
  );
  await page.reload();
  await expect(page.locator("p")).toBeHidden();
  const rejected = await command("save", {
    settings: { ...saved.value.settings, customFilters: ["/(abc)\\1/$script"] },
  });
  expect(rejected.ok).toBe(false);
  expect((await command("status")).value.settings).toEqual(
    saved.value.settings,
  );
  expect((await command("status")).value.pending).toBe(false);
  // Simulate interruption between native effects and the committed settings write.
  await extension.worker.evaluate(async () => {
    await EWE.filters.add(["lab.quietblock.test##h1"]);
    await chrome.storage.local.set({ "quietblock.pending": true });
  });
  const cdp = await extension.context.newCDPSession(control);
  await cdp.send("ServiceWorker.enable");
  await cdp.send("ServiceWorker.stopAllWorkers");
  const recovered = await command("status");
  expect(recovered.ok).toBe(true);
  expect(recovered.value.pending).toBe(false);
  expect(
    await control.evaluate(
      async () => (await chrome.alarms.get("quietblock.updates")).scheduledTime,
    ),
  ).toBe(alarm.scheduledTime);
  await page.reload();
  await expect(page.locator("h1")).toBeVisible();
  await expect(page.locator("p")).toBeHidden();
  expect(extension.errors).toEqual([]);
});

test("unchanged saves preserve revision and still repair missing browser rules", async ({
  extension,
  laboratory,
}) => {
  const control = await extension.context.newPage();
  await control.goto(`chrome-extension://${extension.id}/test-control.html`);
  const command = (command, extra = {}) =>
    control.evaluate(
      (message) =>
        chrome.runtime.sendMessage({ channel: "quietblock", ...message }),
      { command, ...extra },
    );
  const initial = await command("status");
  await extension.worker.evaluate(() => {
    globalThis.rulesetUpdates = 0;
    const update = chrome.declarativeNetRequest.updateEnabledRulesets.bind(
      chrome.declarativeNetRequest,
    );
    chrome.declarativeNetRequest.updateEnabledRulesets = (...args) => {
      globalThis.rulesetUpdates++;
      return update(...args);
    };
  });
  const unchanged = await command("save", { settings: initial.value.settings });
  expect(unchanged.ok).toBe(true);
  expect(unchanged.value.revision).toBe(initial.value.revision);
  expect(await extension.worker.evaluate(() => globalThis.rulesetUpdates)).toBe(
    0,
  );
  const rulesets = await extension.worker.evaluate(() =>
    chrome.declarativeNetRequest.getEnabledRulesets(),
  );
  await extension.worker.evaluate(
    (id) =>
      chrome.declarativeNetRequest.updateEnabledRulesets({
        disableRulesetIds: [id],
      }),
    rulesets[0],
  );
  const repaired = await command("save", { settings: initial.value.settings });
  expect(repaired.ok).toBe(true);
  expect(repaired.value.revision).toBe(initial.value.revision);
  expect(
    await extension.worker.evaluate(() =>
      chrome.declarativeNetRequest.getEnabledRulesets(),
    ),
  ).toEqual(rulesets);
  expect(await extension.worker.evaluate(() => globalThis.rulesetUpdates)).toBe(
    2,
  );
  const page = await extension.context.newPage();
  await page.goto(laboratory.url);
  expect(
    laboratory.requests.some((request) => request.path === "/allowed.js"),
  ).toBe(true);
  expect(laboratory.requests.some((request) => request.path === "/ad.js")).toBe(
    false,
  );
  await expect(page.locator(".sponsored")).toBeHidden();
  expect(extension.errors).toEqual([]);
});
