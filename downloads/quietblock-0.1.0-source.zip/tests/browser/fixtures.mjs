import { test as base, chromium, expect } from "@playwright/test";
import { mkdtemp, mkdir, rm } from "node:fs/promises";
import http from "node:http";
import path from "node:path";
import { createHash } from "node:crypto";

export { expect };
export const test = base.extend({
  extensionPath: [
    process.env.QUIETBLOCK_EXTENSION || "artifacts/extension-test",
    { option: true },
  ],
  laboratory: async ({}, use) => {
    const requests = [];
    let port;
    const server = http.createServer((req, res) => {
      requests.push({ host: req.headers.host, path: req.url });
      if (req.url === "/production") {
        res.setHeader("Content-Type", "text/html");
        res.end(
          `<!doctype html><h1>Readable production fixture</h1><div class="ad-banner-300">Advertisement</div><p>Content remains visible</p><script src="http://ad.doubleclick.net:${port}/advertisement.js"></script>`,
        );
        return;
      }
      if (req.url === "/fetch.json") {
        res.setHeader("Content-Type", "application/json");
        res.end('{"ads":true,"content":"kept"}');
        return;
      }
      if (req.url === "/probe-worker.js") {
        res.setHeader("Content-Type", "application/javascript");
        res.end(
          'fetch("/fetch.json").then(r=>r.json()).then(data=>postMessage({ads:data.ads,property:typeof self.adRuntime}));',
        );
        return;
      }
      if (req.url === "/strict.js") {
        res.setHeader("Content-Type", "application/javascript");
        res.end(
          "window.adRuntime={ready:false};window.adCheck=()=>true;window.earlyDetector={ready:adRuntime.ready,blocked:adCheck()};",
        );
        return;
      }
      if (req.url.endsWith(".js")) {
        res.setHeader("Content-Type", "application/javascript");
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.end(
          req.url === "/allowed.js"
            ? "window.allowedLoaded = true;"
            : "window.adLoaded = true;",
        );
        return;
      }
      res.setHeader("Content-Type", "text/html");
      if (req.url === "/strict") {
        res.setHeader(
          "Content-Security-Policy",
          "script-src 'self'; object-src 'none'",
        );
        res.end(
          '<!doctype html><script src="/strict.js"></script><h1>Strict CSP</h1><div class="sponsored">Advertisement</div>',
        );
        return;
      }
      if (req.url === "/child") {
        res.end(
          '<!doctype html><script>window.adBlocked=true</script><h1>Frame content</h1><div class="sponsored">Advertisement</div>',
        );
        return;
      }
      if (req.url === "/frames") {
        res.end(
          `<!doctype html><h1>Frames</h1><iframe id="same" src="/child"></iframe><iframe id="cross" src="http://frame.quietblock.test:${port}/child"></iframe><iframe id="sandbox" sandbox="allow-scripts" srcdoc="<p>Sandbox content</p>"></iframe>`,
        );
        return;
      }
      if (req.url === "/heavy") {
        res.end(
          '<!doctype html><h1>Ordinary content</h1><div id="heavy-ad">Sponsored</div>',
        );
        return;
      }
      if (req.url === "/detectors") {
        const hash = createHash("sha256")
          .update("window.adLoaded = true;")
          .digest("base64");
        res.end(`<!doctype html><head><script src="/strict.js"></script>
          <script src="http://ads.quietblock.test:${port}/stub.js" integrity="sha256-${hash}" crossorigin="anonymous" onload="window.integrityPassed=true" onerror="window.integrityPassed=false"></script>
          </head><body><h1>Detector probes</h1><div class="sponsored">Advertisement</div><div class="harmless-bait">Bait</div><section>Sponsor label</section><p>Ordinary content</p>
          <script>fetch('/fetch.json').then(r=>r.json()).then(data=>window.fetchResult=data);new Worker('/probe-worker.js').onmessage=event=>window.workerResult=event.data;</script></body>`);
        return;
      }
      res.end(`<!doctype html><html><head><title>Detector laboratory</title>
        <script>window.adBlocked = true;</script>
        <script src="http://ads.quietblock.test:${port}/ad.js"></script>
        <script src="http://ads.quietblock.test:${port}/allowed.js"></script>
        <script src="http://ads.quietblock.test:${port}/stub.js" onload="window.stubLoaded=true" onerror="window.stubLoaded=false"></script>
        </head><body>
        <h1>Readable content</h1><div class="sponsored">Advertisement</div>
        <div class="harmless-bait">Harmless detector bait</div>
        <article>Sponsored article</article><p>Ordinary content</p>
        </body></html>`);
    });
    await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
    port = server.address().port;
    await use({ url: `http://lab.quietblock.test:${port}`, requests, server });
    server.closeAllConnections();
    await new Promise((resolve) => server.close(resolve));
  },
  extension: async ({ extensionPath: extensionRoot }, use) => {
    const extensionPath = path.resolve(extensionRoot);
    await mkdir(".cache/profiles", { recursive: true });
    const profile = await mkdtemp(path.resolve(".cache/profiles/test-"));
    const context = await chromium.launchPersistentContext(profile, {
      channel: "chromium",
      headless: true,
      args: [
        `--disable-extensions-except=${extensionPath}`,
        `--load-extension=${extensionPath}`,
        "--host-resolver-rules=MAP *.quietblock.test 127.0.0.1, MAP ad.doubleclick.net 127.0.0.1",
        "--no-proxy-server",
      ],
    });
    const errors = [];
    context.on("weberror", (error) => errors.push(error.error().message));
    const worker =
      context.serviceWorkers()[0] ||
      (await context.waitForEvent("serviceworker"));
    worker.on("console", (message) => {
      if (message.type() === "error") errors.push(message.text());
    });
    await expect
      .poll(
        () =>
          worker.evaluate(
            async () =>
              (await chrome.storage.local.get("quietblock.health"))[
                "quietblock.health"
              ],
          ),
        { message: "Engine startup" },
      )
      .toMatchObject({ ready: true });
    await use({ context, worker, errors, id: new URL(worker.url()).host });
    await context.close();
    await rm(profile, { recursive: true, force: true });
  },
});
