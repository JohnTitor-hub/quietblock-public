import assert from "node:assert/strict";
import { createRequire } from "node:module";
import test from "node:test";
const require = createRequire(import.meta.url);
const {
  Downloader,
  Downloadable,
} = require("../../vendor/eyeo-sdk/adblockpluscore/lib/downloader.js");

test("filter downloads omit product, installation, and counting metadata", () => {
  const full = new Downloadable("https://filters.example/list.txt");
  Object.assign(full, {
    firstVersion: "secret",
    lastVersion: 123,
    downloadCount: 4,
  });
  assert.equal(
    Downloader.prototype.getDownloadUrl(full),
    "https://filters.example/list.txt",
  );
  const delta = new Downloadable("https://filters.example/diff.txt");
  Object.assign(delta, {
    originalUrl: full.url,
    lastVersion: 123,
    firstVersion: "secret",
  });
  assert.equal(
    Downloader.prototype.getDownloadUrl(delta),
    "https://filters.example/diff.txt?lastVersion=123",
  );
});
