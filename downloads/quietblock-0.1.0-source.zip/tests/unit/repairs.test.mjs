import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { createRequire } from "node:module";
import test from "node:test";
import { compileRepairs } from "../../tools/repair-catalog.mjs";
import { resolveRepairs } from "../../vendor/eyeo-sdk/src/all/bundled-repairs.js";

const require = createRequire(import.meta.url);
const {
  Filter,
} = require("../../vendor/eyeo-sdk/adblockpluscore/lib/filterClasses.js");
const {
  parseScript,
} = require("../../vendor/eyeo-sdk/adblockpluscore/lib/scriptParsing.js");

test("the packaged catalog preserves every trusted repair scope, argument and command order", async () => {
  const { snapshots } = JSON.parse(await readFile("filters/lock.json", "utf8"));
  const catalog = await compileRepairs(snapshots);
  const expected = new Map();
  for (const snapshot of snapshots.filter((item) => item.privileged)) {
    for (const text of (await readFile(snapshot.path, "utf8")).split(/\r?\n/)) {
      const filter = Filter.fromText(Filter.normalize(text));
      if (filter.type !== "snippet") continue;
      if (!expected.has(filter.text))
        expected.set(filter.text, {
          origins: [],
          commands: parseScript(filter.body),
        });
      expected.get(filter.text).origins.push(snapshot.url);
    }
  }
  assert.equal(expected.size, 2002);
  assert.deepEqual(
    catalog.rules.map(([text]) => text),
    [...expected.keys()],
  );
  for (const [text, origins, body] of catalog.rules) {
    assert.deepEqual(origins, expected.get(text).origins);
    assert.deepEqual(catalog.commands[body], expected.get(text).commands);
  }
  assert.equal(catalog.commands.length, 1455);
});

test("cache and message selections cannot supply commands, arguments or reordered pipelines", () => {
  const catalog = { version: "packaged-version", bodies: [0, 1] };
  const commands = [
    [
      ["override-property-read", "adBlocked", "false"],
      ["replace-argument", "check", "0", "false"],
    ],
    [["hide-if-contains", "Sponsored", "article"]],
  ];
  const config = {
    catalog: catalog.version,
    repairs: [
      [1, [0]],
      [0, [1, 0, 0, 99]],
      [999, [0]],
    ],
    filters: ["override-property-read injected true"],
  };
  assert.deepEqual(resolveRepairs(config, catalog, commands), commands.flat());
  assert.deepEqual(
    resolveRepairs({ ...config, catalog: "old-version" }, catalog, commands),
    [],
  );
  assert.deepEqual(
    resolveRepairs({ filters: config.filters }, catalog, commands),
    [],
  );
  assert.deepEqual(
    resolveRepairs(
      { ...config, repairs: [[0, [1]], ["0", [0]], null] },
      catalog,
      commands,
    ),
    [commands[0][1]],
  );
  assert.deepEqual(
    resolveRepairs(config, catalog, [[null, commands[0][1]], [null]]),
    [commands[0][1]],
  );
});
