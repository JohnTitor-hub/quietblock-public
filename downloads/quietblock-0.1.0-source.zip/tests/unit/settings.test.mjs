import assert from "node:assert/strict";
import test from "node:test";
import { hostname, isPaused, normalizeSettings } from "../../src/settings.ts";

test("settings restrict subscription trust, normalize sites, and retain meaningful rules", () => {
  const base = {
    schema: 1,
    enabledLists: ["https://lists.example/easy.txt"],
    customLists: [],
    pausedHosts: ["HTTPS://News.Example/"],
    customFilters: ["! comment", "||ads.example^", "||ads.example^"],
    snippetCacheDisabledHosts: [],
  };
  const catalog = [{ url: "https://lists.example/easy.txt" }];
  const normalized = normalizeSettings(base, catalog);
  assert.deepEqual(normalized.pausedHosts, ["news.example"]);
  assert.deepEqual(normalized.customFilters, ["||ads.example^"]);
  assert.equal(isPaused("a.news.example", normalized.pausedHosts), true);
  assert.equal(isPaused("badnews.example", normalized.pausedHosts), false);
  for (const url of [
    "https://FILTERS.example/list.txt",
    "https://filters.example",
  ]) {
    const result = normalizeSettings(
      { ...base, enabledLists: [url], customLists: [{ url, title: "Custom" }] },
      catalog,
    );
    assert.equal(result.enabledLists[0], new URL(url).href);
  }
  for (const host of [
    "example.com/path",
    "javascript:alert(1)",
    "https://user:pass@example.com",
  ])
    assert.throws(() => hostname(host));
  for (const url of [
    "http://lists.example/x",
    "https://user:pass@lists.example/x",
  ])
    assert.throws(() =>
      normalizeSettings(
        { ...base, customLists: [{ url, title: "Untrusted" }] },
        catalog,
      ),
    );
  assert.throws(() =>
    normalizeSettings(
      { ...base, enabledLists: ["https://unknown.example"] },
      catalog,
    ),
  );
});
