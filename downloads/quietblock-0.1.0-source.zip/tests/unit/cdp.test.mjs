import { test } from "node:test";
import assert from "node:assert/strict";
import { EventEmitter } from "node:events";
import { attachTarget } from "../../tools/cdp.mjs";

test("target calls and profiling events stay scoped and disposal detaches Chrome", async () => {
  const browser = new EventEmitter();
  const sent = [];
  browser.send = async (method, params) => {
    sent.push({ method, params });
    if (method === "Target.attachToTarget")
      return { sessionId: "worker-session" };
    if (method === "Target.sendMessageToTarget") {
      const { id } = JSON.parse(params.message);
      browser.emit("Target.receivedMessageFromTarget", {
        sessionId: "worker-session",
        message: JSON.stringify({ id, result: { usedSize: 42 } }),
      });
    }
  };
  const events = [];
  const channel = await attachTarget(browser, "worker", (event) =>
    events.push(event),
  );
  assert.deepEqual(await channel.call("Runtime.getHeapUsage"), {
    usedSize: 42,
  });
  for (const sessionId of ["another-session", "worker-session"])
    browser.emit("Target.receivedMessageFromTarget", {
      sessionId,
      message: JSON.stringify({
        method: "HeapProfiler.addHeapSnapshotChunk",
        params: { chunk: "{}" },
      }),
    });
  assert.equal(events.length, 1);
  await channel.dispose();
  assert.deepEqual(sent.at(-1), {
    method: "Target.detachFromTarget",
    params: { sessionId: "worker-session" },
  });
  assert.equal(browser.listenerCount("Target.receivedMessageFromTarget"), 0);
});
