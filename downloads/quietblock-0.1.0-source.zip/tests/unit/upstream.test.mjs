import assert from "node:assert/strict";
import { createRequire } from "node:module";
import test from "node:test";

const require = createRequire(import.meta.url);
const {
  createConverter,
} = require("../../vendor/eyeo-sdk/adblockpluscore/lib/dnr/index.js");
const {
  parseScript,
} = require("../../vendor/eyeo-sdk/adblockpluscore/lib/scriptParsing.js");
const {
  Filter,
} = require("../../vendor/eyeo-sdk/adblockpluscore/lib/filterClasses.js");

test("upstream converts blocking, exceptions, domain scope, and redirects", async () => {
  const convert = createConverter({ isRegexSupported: () => true });
  const [block] = await convert(
    "||ads.example^$script,third-party,domain=news.example",
  );
  assert.equal(block.action.type, "block");
  assert.deepEqual(block.condition.resourceTypes, ["script"]);
  assert.equal(block.condition.domainType, "thirdParty");
  assert.deepEqual(block.condition.initiatorDomains, ["news.example"]);
  const [allow] = await convert("@@||ads.example/needed.js$script");
  assert.equal(allow.action.type, "allow");
  const [redirect] = await convert(
    "||ads.example/loader.js$script,domain=news.example,rewrite=abp-resource:blank-js",
  );
  assert.equal(redirect.action.type, "redirect");
});

test("upstream parses quoted snippet arguments and multiple operations", () => {
  assert.deepEqual(
    parseScript(
      "override-property-read adBlocked false; hide-if-contains 'Sponsored post' article",
    ),
    [
      ["override-property-read", "adBlocked", "false"],
      ["hide-if-contains", "Sponsored post", "article"],
    ],
  );
});

test("domain activation preserves exceptions and wildcard precedence without scanning literal lists", () => {
  const cases = [
    ["example.com##.ad", "sub.example.com", undefined, true],
    ["example.com##.ad", "other.test", undefined, false],
    ["~example.com##.ad", "other.test", undefined, true],
    ["~example.com##.ad", "sub.example.com", undefined, false],
    [
      "example.com,~private.example.com##.ad",
      "private.example.com",
      undefined,
      false,
    ],
    [
      "example.com,~private.example.com##.ad",
      "other.example.com.",
      undefined,
      true,
    ],
    ["example.*##.ad", "sub.example.co.uk", undefined, true],
    ["example.*##.ad", "other.com", undefined, false],
    ["~example.*##.ad", "example.net", undefined, false],
    ["example.*,~example.org##.ad", "example.org", undefined, false],
    ["example.org,~example.*##.ad", "example.org", undefined, true],
    ["example.com##.ad", "", undefined, false],
    ["~example.com##.ad", null, undefined, true],
    [
      "||ads.test^$domain=news.test|~private.news.test,sitekey=ABC",
      "news.test",
      "ABC",
      true,
    ],
    [
      "||ads.test^$domain=news.test|~private.news.test,sitekey=ABC",
      "news.test",
      "abc",
      false,
    ],
  ];
  for (const [rule, host, key, expected] of cases)
    assert.equal(
      Filter.fromText(rule).isActiveOnDomain(host, key),
      expected,
      `${rule} on ${host}`,
    );

  const literal = Filter.fromText(
    "~excluded-a.test,~excluded-b.test##.literal-ad",
  );
  const domains = literal.domains;
  const entries = domains.entries.bind(domains);
  let scans = 0;
  domains.entries = () => {
    scans++;
    return entries();
  };
  try {
    assert.equal(literal.isActiveOnDomain("unrelated.example"), true);
    assert.equal(scans, 0);
  } finally {
    delete domains.entries;
  }
});
