import {
  hostname,
  normalizeSettings,
  pauseRule,
  type Settings,
} from "./settings";
const SETTINGS = "quietblock.settings";
const HEALTH = "quietblock.health";
const PENDING = "quietblock.pending";
let settings: Settings;
const REVISION = "quietblock.revision";
let revision = 0;
let serial: Promise<unknown> = Promise.resolve();
const enqueue = <T>(operation: () => Promise<T>) => {
  const result = serial.then(operation);
  serial = result.catch(() => {});
  return result;
};
const defaults = (): Settings => ({
  schema: 1,
  enabledLists: BUNDLED_SUBSCRIPTIONS.filter((list) => list.enabled).map(
    (list) => list.url,
  ),
  customLists: [],
  pausedHosts: [],
  customFilters: [],
  snippetCacheDisabledHosts: [],
});
function parseSettings(value: unknown): Settings {
  const next = normalizeSettings(value, BUNDLED_SUBSCRIPTIONS);
  // DNR stores canonical text; reconcile and persist the same spelling.
  next.customFilters = [
    ...new Set(next.customFilters.map((text) => EWE.filters.normalize(text))),
  ];
  return next;
}
async function reconcile(next: Settings) {
  const wanted = new Set([
    ...next.customFilters,
    ...next.pausedHosts.map(pauseRule),
  ]);
  const [filters, subscriptions, enabledRulesets] = await Promise.all([
    EWE.filters.getUserFilters(),
    EWE.subscriptions.getSubscriptions(),
    chrome.declarativeNetRequest.getEnabledRulesets(),
  ]);
  const actual = new Set(filters.map((filter) => filter.text));
  const installed = new Map(subscriptions.map((list) => [list.url, list]));
  const activeRulesets = new Set(enabledRulesets);
  // Add first: quota or conversion failure must leave the old rules intact.
  const additions = [...wanted].filter((text) => !actual.has(text));
  if (additions.length) await EWE.filters.add(additions);
  for (const list of [...BUNDLED_SUBSCRIPTIONS, ...next.customLists]) {
    const enabled = next.enabledLists.includes(list.url);
    const current = installed.get(list.url);
    const bundled = BUNDLED_SUBSCRIPTIONS.find((item) => item.url === list.url);
    if (!current) {
      if (!enabled) continue;
      await EWE.subscriptions.add(list.url, {
        privileged: bundled?.privileged ?? false,
        ...(bundled ? { lastDownload: Math.floor(Date.now() / 1000) } : {}),
      });
    }
    // Native rules can be missing even when the persisted subscription says on.
    const nativeEnabled = bundled ? activeRulesets.has(bundled.id) : enabled;
    if (enabled && (!current?.enabled || !nativeEnabled))
      await EWE.subscriptions.enable(list.url);
    else if (!enabled && (current?.enabled || nativeEnabled))
      await EWE.subscriptions.disable(list.url);
  }
  const known = new Set(
    [...BUNDLED_SUBSCRIPTIONS, ...next.customLists].map((list) => list.url),
  );
  for (const list of subscriptions) {
    if (!known.has(list.url) && list.enabled)
      await EWE.subscriptions.disable(list.url);
  }
  const removals = [...actual].filter((text) => !wanted.has(text));
  if (removals.length) await EWE.filters.remove(removals);
}
async function save(value: unknown, expectedRevision?: number) {
  if (expectedRevision !== undefined && expectedRevision !== revision)
    throw new Error(
      "Settings changed elsewhere. Copy any edits you want to keep, reload this page, and try again.",
    );
  const next = parseSettings(value);
  const changed = JSON.stringify(next) !== JSON.stringify(settings);
  for (const text of changed ? next.customFilters : []) {
    const error = await EWE.filters.validate(text);
    if (error) throw new Error(`Invalid filter: ${text} (${error.message})`);
  }
  await chrome.storage.local.set({ [PENDING]: true });
  try {
    await reconcile(next);
    if (changed) {
      await chrome.storage.local.set({
        [SETTINGS]: next,
        [REVISION]: revision + 1,
      });
      settings = next;
      revision++;
    }
    await chrome.storage.local.remove(PENDING);
  } catch (error) {
    try {
      await reconcile(settings);
      await chrome.storage.local.remove(PENDING);
    } catch {
      /* The committed settings are reconciled on the next worker start. */
    }
    throw error;
  }
}
async function status() {
  const lists = await EWE.subscriptions.getSubscriptions();
  const pending = Boolean((await chrome.storage.local.get(PENDING))[PENDING]);
  return { settings, revision, catalog: BUNDLED_SUBSCRIPTIONS, lists, pending };
}
const ready = EWE.start({
  bundledSubscriptions: BUNDLED_SUBSCRIPTIONS,
  bundledSubscriptionsPath: "subscriptions",
  heavyDependenciesPath: "engine-heavy.js",
  ...(REFERENCE_ENGINE ? { lightningSnippets: true } : {}),
}).then(async ({ warnings }) => {
  const stored = await chrome.storage.local.get([
    SETTINGS,
    REVISION,
    HEALTH,
    PENDING,
  ]);
  revision =
    typeof stored[REVISION] === "number" &&
    Number.isSafeInteger(stored[REVISION])
      ? stored[REVISION]
      : 0;
  settings = stored[SETTINGS] ? parseSettings(stored[SETTINGS]) : defaults();
  await reconcile(settings);
  const updates: Record<string, unknown> = {};
  if (JSON.stringify(stored[SETTINGS]) !== JSON.stringify(settings))
    updates[SETTINGS] = settings;
  const health = { ready: true, warnings };
  if (JSON.stringify(stored[HEALTH]) !== JSON.stringify(health))
    updates[HEALTH] = health;
  if (Object.keys(updates).length) await chrome.storage.local.set(updates);
  if (stored[PENDING]) await chrome.storage.local.remove(PENDING);
  if (!(await chrome.alarms.get("quietblock.updates")))
    await chrome.alarms.create("quietblock.updates", { periodInMinutes: 60 });
  if (!REFERENCE_ENGINE) await EWE.subscriptions.checkForUpdates();
});
ready.catch(async (error: unknown) => {
  await chrome.storage.local.set({
    [HEALTH]: {
      ready: false,
      error: error instanceof Error ? error.message : String(error),
    },
  });
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "quietblock.updates")
    void enqueue(async () => {
      await ready;
      if (!REFERENCE_ENGINE) await EWE.subscriptions.checkForUpdates();
    });
});
// Only extension pages can change settings; content scripts keep their native eyeo protocol.
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message?.channel !== "quietblock") return;
  if (
    sender.id !== chrome.runtime.id ||
    !sender.url?.startsWith(chrome.runtime.getURL(""))
  ) {
    respond({ ok: false, error: "Extension pages only." });
    return;
  }
  void enqueue(async () => {
    await ready;
    if (message.command === "status") return status();
    if (message.command === "save") {
      await save(message.settings, message.expectedRevision);
      return status();
    }
    if (message.command === "pause") {
      const host = hostname(message.host);
      const pausedHosts = settings.pausedHosts.filter((item) => item !== host);
      if (message.paused) pausedHosts.push(host);
      await save({ ...settings, pausedHosts });
      return status();
    }
    if (message.command === "update") {
      await EWE.subscriptions.sync();
      return status();
    }
    throw new Error("Unknown command.");
  }).then(
    (value) => respond({ ok: true, value }),
    (error) =>
      respond({
        ok: false,
        error: error instanceof Error ? error.message : String(error),
      }),
  );
  return true;
});
