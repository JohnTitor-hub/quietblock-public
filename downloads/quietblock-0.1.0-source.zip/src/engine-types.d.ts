interface FilterResult {
  text: string;
  type: string;
  enabled: boolean;
}
interface SubscriptionResult {
  id: string;
  url: string;
  title: string;
  enabled: boolean;
  downloadStatus: string;
  version: number;
  lastDownload: number;
  downloading: boolean;
  downloadError?: string;
}
interface BundledSubscription {
  id: string;
  url: string;
  title: string;
  type: string;
  privileged: boolean;
  enabled: boolean;
  languages: string[];
  rule_count: number;
  diff_url?: string;
}
interface EyeoApi {
  start(config: {
    bundledSubscriptions: BundledSubscription[];
    bundledSubscriptionsPath: string;
    heavyDependenciesPath: string;
    lightningSnippets?: boolean;
  }): Promise<{ warnings: string[] }>;
  subscriptions: {
    has(url: string): Promise<boolean>;
    add(
      url: string,
      options?: { privileged?: boolean; lastDownload?: number },
    ): Promise<void>;
    enable(url: string): Promise<void>;
    disable(url: string): Promise<void>;
    sync(url?: string): Promise<void>;
    checkForUpdates(): Promise<void>;
    getSubscriptions(): Promise<SubscriptionResult[]>;
  };
  filters: {
    add(texts: string[]): Promise<void>;
    remove(texts: string[]): Promise<void>;
    getUserFilters(): Promise<FilterResult[]>;
    normalize(text: string): string;
    validate(text: string): { message: string } | null;
  };
}
declare const EWE: EyeoApi;
declare const BUNDLED_SUBSCRIPTIONS: BundledSubscription[];

declare const REFERENCE_ENGINE: boolean;
