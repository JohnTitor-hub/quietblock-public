export interface Settings {
  schema: 1;
  enabledLists: string[];
  customLists: { url: string; title: string }[];
  pausedHosts: string[];
  customFilters: string[];
  snippetCacheDisabledHosts: string[];
}

export function hostname(value: string): string {
  const parsed = new URL(value.includes("://") ? value : `https://${value}`);
  if (
    !["http:", "https:"].includes(parsed.protocol) ||
    parsed.username ||
    parsed.password ||
    parsed.pathname !== "/" ||
    parsed.search ||
    parsed.hash
  )
    throw new Error("Enter a hostname, such as example.com.");
  return parsed.hostname.toLowerCase().replace(/\.$/, "");
}
export const pauseRule = (host: string) => `@@||${host}^$document`;
export const isPaused = (host: string, pausedHosts: string[]) =>
  pausedHosts.some((paused) => host === paused || host.endsWith(`.${paused}`));
export function normalizeSettings(
  value: unknown,
  catalog: BundledSubscription[],
): Settings {
  if (!value || typeof value !== "object")
    throw new Error("Invalid settings file.");
  const input = value as Record<string, unknown>;
  if (input.schema !== 1) throw new Error("Unsupported settings version.");
  const strings = (key: string, max = 20_000): string[] => {
    const items = input[key];
    if (
      !Array.isArray(items) ||
      items.length > max ||
      items.some((item) => typeof item !== "string" || item.length > 16_000)
    )
      throw new Error(`Invalid ${key}.`);
    return [
      ...new Set(
        (items as string[]).map((item) => item.trim()).filter(Boolean),
      ),
    ];
  };
  if (!Array.isArray(input.customLists) || input.customLists.length > 20)
    throw new Error("Too many custom subscriptions.");
  const customLists = input.customLists.map((item) => {
    if (
      !item ||
      typeof item.url !== "string" ||
      typeof item.title !== "string" ||
      item.title.length > 200
    )
      throw new Error("Invalid custom subscription.");
    const url = new URL(item.url);
    if (url.protocol !== "https:" || url.username || url.password || url.hash)
      throw new Error(
        "Custom subscriptions require an HTTPS URL without credentials.",
      );
    return { url: url.href, title: item.title };
  });
  const known = new Set([
    ...catalog.map((list) => list.url),
    ...customLists.map((list) => list.url),
  ]);
  const enabledLists = [
    ...new Set(strings("enabledLists", 100).map((url) => new URL(url).href)),
  ];
  if (enabledLists.some((url) => !known.has(url)))
    throw new Error("Unknown subscription selected.");
  return {
    schema: 1,
    enabledLists,
    customLists,
    pausedHosts: strings("pausedHosts", 1000).map(hostname),
    customFilters: strings("customFilters").filter(
      (text) => !text.startsWith("!") && !text.startsWith("["),
    ),
    snippetCacheDisabledHosts: strings("snippetCacheDisabledHosts", 1000).map(
      hostname,
    ),
  };
}
