import { command, element, errorText, message, type State } from "./api";
import type { Settings } from "../src/settings";
let state: State;
let dirty = false;
const form = element<HTMLFormElement>("settings-form");
const save = element<HTMLButtonElement>("save");
const lines = (id: string) =>
  element<HTMLTextAreaElement>(id)
    .value.split(/\r?\n/)
    .map((text) => text.trim())
    .filter(Boolean);
const statusNodes = new Map<string, HTMLElement>();
const startupControls = form.querySelectorAll<
  HTMLInputElement | HTMLButtonElement | HTMLTextAreaElement
>("input,button,textarea");
startupControls.forEach((node) => (node.disabled = true));
form.setAttribute("aria-busy", "true");
function updateStates(next: State) {
  state.lists = next.lists;
  for (const [url, node] of statusNodes) {
    const list = state.lists.find((item) => item.url === url);
    const failed =
      list?.downloadStatus?.startsWith("synchronize_") &&
      list.downloadStatus !== "synchronize_ok";
    node.dataset.error = String(Boolean(failed));
    node.textContent = !list?.enabled
      ? "Off"
      : list.downloading
        ? "Updating…"
        : failed
          ? "Update failed · using the last working rules"
          : `On${list.version ? ` · version ${list.version}` : ""}${list.lastDownload && list.downloadStatus ? ` · checked ${new Date(list.lastDownload * 1000).toLocaleDateString()}` : state.catalog.some((item) => item.url === url) ? " · bundled rules" : " · awaiting first download"}`;
  }
}
function render(next: State) {
  state = next;
  const lists = element("lists");
  lists.replaceChildren();
  statusNodes.clear();
  for (const list of [...next.catalog, ...next.settings.customLists]) {
    const label = document.createElement("label");
    label.className = "filter-row";
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.name = "list";
    checkbox.value = list.url;
    checkbox.checked = next.settings.enabledLists.includes(list.url);
    const text = document.createElement("span");
    const title = document.createElement("span");
    title.className = "filter-title";
    title.textContent =
      "type" in list && list.type === "circumvention"
        ? "Site repairs (eyeo)"
        : list.title;
    const detail = document.createElement("span");
    detail.className = "filter-detail";
    statusNodes.set(list.url, detail);
    text.append(title, detail);
    label.append(checkbox, text);
    lists.append(label);
  }
  element<HTMLTextAreaElement>("paused-hosts").value =
    next.settings.pausedHosts.join("\n");
  element<HTMLTextAreaElement>("custom-filters").value =
    next.settings.customFilters.join("\n");
  element<HTMLTextAreaElement>("custom-lists").value = next.settings.customLists
    .map((list) => list.url)
    .join("\n");
  element<HTMLTextAreaElement>("cache-disabled").value =
    next.settings.snippetCacheDisabledHosts.join("\n");
  updateStates(next);
  dirty = false;
  save.disabled = true;
  void pollUpdates();
}
let polling = false;
async function pollUpdates() {
  if (polling) return;
  polling = true;
  try {
    for (
      let attempt = 0;
      attempt < 30 && state.lists.some((list) => list.downloading);
      attempt++
    ) {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      updateStates(await command("status"));
    }
  } catch (error) {
    element("update-status").textContent = errorText(error);
  } finally {
    polling = false;
  }
}
async function apply(settings: Settings) {
  const controls = form.querySelectorAll<
    HTMLInputElement | HTMLTextAreaElement | HTMLButtonElement
  >("input,textarea,button");
  controls.forEach((node) => (node.disabled = true));
  form.setAttribute("aria-busy", "true");
  message("Saving…");
  try {
    render(
      await command("save", { settings, expectedRevision: state.revision }),
    );
    message("Saved. Reload open sites to apply changes.");
  } catch (error) {
    message(errorText(error), true);
    throw error;
  } finally {
    controls.forEach((node) => (node.disabled = false));
    save.disabled = !dirty;
    form.removeAttribute("aria-busy");
  }
}
form.addEventListener("input", () => {
  dirty = true;
  save.disabled = false;
  message("Unsaved changes");
});
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const customLists = lines("custom-lists").map(
      (url) =>
        state.settings.customLists.find((list) => list.url === url) || {
          url,
          title: url,
        },
    );
    const selected = [
      ...form.querySelectorAll<HTMLInputElement>('input[name="list"]:checked'),
    ].map((node) => node.value);
    const newLists = customLists.filter(
      (list) => !state.settings.customLists.some((old) => old.url === list.url),
    );
    await apply({
      ...state.settings,
      customLists,
      enabledLists: [
        ...selected.filter(
          (url) =>
            state.catalog.some((list) => list.url === url) ||
            customLists.some((list) => list.url === url),
        ),
        ...newLists.map((list) => list.url),
      ],
      pausedHosts: lines("paused-hosts"),
      customFilters: lines("custom-filters"),
      snippetCacheDisabledHosts: lines("cache-disabled"),
    });
  } catch (error) {
    message(errorText(error), true);
  }
});
element("export").onclick = () => {
  const url = URL.createObjectURL(
    new Blob([JSON.stringify(state.settings, null, 2)], {
      type: "application/json",
    }),
  );
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = "quietblock-settings.json";
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  message("Saved settings exported.");
};
element<HTMLInputElement>("import").onchange = async (event) => {
  const input = event.target as HTMLInputElement;
  const file = input.files?.[0];
  if (!file) return;
  try {
    if (file.size > 2_000_000)
      throw new Error("Settings backup must be smaller than 2 MB.");
    await apply(JSON.parse(await file.text()));
  } catch (error) {
    message(errorText(error), true);
  } finally {
    input.value = "";
  }
};
element("update").onclick = async () => {
  const button = element<HTMLButtonElement>("update");
  const node = element("update-status");
  button.disabled = true;
  node.textContent = "Checking for filter updates…";
  try {
    updateStates(await command("update"));
    await pollUpdates();
    node.textContent = state.lists.some(
      (list) =>
        list.enabled &&
        list.downloadStatus &&
        list.downloadStatus !== "synchronize_ok",
    )
      ? "Some updates failed. Existing protection is still active."
      : state.lists.some((list) => list.downloading)
        ? "Updates are still running. You can close this page."
        : "Filter check complete.";
  } catch (error) {
    node.textContent = errorText(error);
  } finally {
    button.disabled = false;
  }
};
command("status")
  .then((next) => {
    render(next);
    startupControls.forEach((node) => (node.disabled = false));
    save.disabled = true;
    form.removeAttribute("aria-busy");
    message("");
  })
  .catch((error) => {
    message(errorText(error), true);
    form
      .querySelectorAll<
        HTMLInputElement | HTMLButtonElement | HTMLTextAreaElement
      >("input,button,textarea")
      .forEach((node) => (node.disabled = true));
  });
