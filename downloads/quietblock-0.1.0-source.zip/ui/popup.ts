import { command, element, errorText, message } from "./api";
import { isPaused } from "../src/settings";
const toggle = element<HTMLButtonElement>("toggle");
async function start() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const url = tab?.url ? new URL(tab.url) : null;
  if (
    !url ||
    !["http:", "https:"].includes(url.protocol) ||
    tab.id === undefined
  ) {
    element("site").textContent = "Browser page";
    element("protection").textContent = "No site controls here";
    element("explanation").textContent =
      "Open a website to change its protection.";
    toggle.textContent = "Website required";
    return;
  }
  const host = url.hostname;
  const state = await command("status");
  const paused = isPaused(host, state.settings.pausedHosts);
  const matching = state.settings.pausedHosts.filter((item) =>
    isPaused(host, [item]),
  );
  element("site").textContent = host;
  document.body.dataset.paused = String(paused);
  element("protection").textContent = paused
    ? "Protection paused"
    : "Protection on";
  element("explanation").textContent = paused
    ? `Paused for ${matching.join(", ")} and subdomains.`
    : "Ads, tracking, and known site countermeasures are filtered.";
  toggle.textContent = paused ? "Resume & reload" : "Pause & reload";
  toggle.disabled = false;
  toggle.onclick = async () => {
    toggle.disabled = true;
    try {
      if (paused)
        for (const item of matching)
          await command("pause", { host: item, paused: false });
      else await command("pause", { host, paused: true });
      await chrome.tabs.reload(tab.id!);
      window.close();
    } catch (error) {
      message(errorText(error), true);
      toggle.disabled = false;
    }
  };
}
start().catch((error) => {
  element("site").textContent = "Protection needs attention";
  element("protection").textContent = "Unable to read settings";
  toggle.textContent = "Unavailable";
  message(errorText(error), true);
});
