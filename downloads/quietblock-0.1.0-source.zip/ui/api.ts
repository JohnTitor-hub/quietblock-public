import type { Settings } from "../src/settings";
export interface State {
  revision: number;
  settings: Settings;
  catalog: BundledSubscription[];
  lists: SubscriptionResult[];
  pending: boolean;
}
export async function command(
  command: string,
  extra: Record<string, unknown> = {},
): Promise<State> {
  const response = await chrome.runtime.sendMessage({
    channel: "quietblock",
    command,
    ...extra,
  });
  if (!response?.ok)
    throw new Error(
      response?.error ||
        "The extension did not respond. Reload the extension and try again.",
    );
  return response.value;
}
export function element<T extends HTMLElement = HTMLElement>(id: string): T {
  const node = document.getElementById(id);
  if (!node) throw new Error(`Missing control: ${id}`);
  return node as T;
}
export function message(text: string, error = false) {
  const node = element("message");
  node.textContent = text;
  node.dataset.error = String(error);
  node.setAttribute("role", error ? "alert" : "status");
}
export function errorText(error: unknown): string {
  const text = error instanceof Error ? error.message : String(error);
  if (/filter_invalid|invalid_filter|not_supported/.test(text))
    return "Invalid or unsupported filter. Check the rule syntax; your saved settings are unchanged.";
  if (/too_many_filters|rule.*limit/i.test(text))
    return "Chrome's rule limit was reached. Remove some custom rules or lists and try again.";
  return text;
}
